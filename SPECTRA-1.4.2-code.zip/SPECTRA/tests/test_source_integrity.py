"""Lightweight source-regression tests that do not require Qt or Windows."""
from __future__ import annotations

import ast
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]
APP_PATH = ROOT / "app.py"
RUN_PATH = ROOT / "run.bat"
CHECK_PATH = ROOT / "check.bat"


class SourceIntegrityTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.source = APP_PATH.read_text(encoding="utf-8")
        cls.tree = ast.parse(cls.source, filename=str(APP_PATH))
        cls.app_class = next(
            node for node in cls.tree.body
            if isinstance(node, ast.ClassDef) and node.name == "App"
        )
        cls.methods = {
            node.name for node in cls.app_class.body
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
        }

    def test_app_methods_are_unique(self):
        names = [
            node.name for node in self.app_class.body
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
        ]
        self.assertEqual(len(names), len(set(names)), "Duplicate App methods can shadow real implementations")

    def test_direct_signal_handlers_exist(self):
        missing = []
        for node in ast.walk(self.app_class):
            if not isinstance(node, ast.Call) or not isinstance(node.func, ast.Attribute) or node.func.attr != "connect" or not node.args:
                continue
            handler = node.args[0]
            if (isinstance(handler, ast.Attribute) and isinstance(handler.value, ast.Name)
                    and handler.value.id == "self" and handler.attr not in self.methods):
                missing.append((handler.attr, node.lineno))
        self.assertEqual(missing, [], f"Signal handlers do not exist: {missing}")

    def test_key_regression_methods_exist(self):
        for name in (
            "select_headset", "start_device_scan", "_on_scan_completed", "toggle_stream",
            "_poll_scrcpy_window", "stop_stream", "screenshot", "export_diagnostics",
            "_restore_keep_awake", "install_tools", "_activate_device_calibration",
            "_resume_stream_if_ready", "_redact_diagnostics", "_format_calibration_adjustment",
        ):
            self.assertIn(name, self.methods)

    def test_launcher_is_ascii_and_windows_crlf(self):
        payload = RUN_PATH.read_bytes()
        payload.decode("ascii")
        self.assertNotIn(b"\n", payload.replace(b"\r\n", b""), "run.bat must use Windows CRLF line endings")

    def test_check_launcher_is_ascii_and_windows_crlf(self):
        payload = CHECK_PATH.read_bytes()
        payload.decode("ascii")
        self.assertNotIn(b"\n", payload.replace(b"\r\n", b""))
        self.assertIn(b"unittest discover", payload)

    def test_settings_json_is_valid_and_marks_unimplemented_features_off(self):
        import json
        cfg = json.loads((ROOT / "config" / "settings.json").read_text(encoding="utf-8"))
        self.assertFalse(cfg.get("auto_bitrate", True))
        self.assertIsInstance(cfg.get("keep_awake_originals", {}), dict)
        self.assertIsInstance(cfg.get("calibration_profiles", {}), dict)
        self.assertEqual(cfg.get("resolution"), "720p")
        self.assertEqual(str(cfg.get("fps")), "30")
        self.assertEqual(cfg.get("bitrate"), 16)
        self.assertEqual(cfg.get("calibration"), {"x": -16, "y": 0, "width": 77, "height": 40, "rotation": 0})

    def test_direct_app_start_does_not_implicitly_install_packages(self):
        self.assertNotIn("subprocess.check_call", self.source)
        self.assertIn("_report_missing_pyside6", self.source)

    def test_corrupt_settings_are_backed_up_before_defaults_are_used(self):
        self.assertIn("settings.corrupt-", self.source)
        self.assertIn("shutil.copy2(CONFIG_PATH,backup)", self.source)

    def test_wifi_connect_supports_auto_ip_over_usb(self):
        self.assertIn("_discover_wifi_address", self.source)
        self.assertIn("parse_android_ip(output)", self.source)
        self.assertIn("completed = Signal(bool, str, str)", self.source)
        self.assertIn("wifi_worker.completed.connect(self._on_wifi_completed)", self.source)
        self.assertIn("if addr and not valid_ipv4(addr):", self.source)
        self.assertIn("if not addr and not usb_serial:", self.source)
        self.assertIn('ip_auto=QPushButton("Авто IP")', self.source)
        self.assertIn("ip_auto.clicked.connect(lambda:ip.clear())", self.source)
        self.assertNotIn("completed.connect(lambda ok,message,a=addr:self._on_wifi_completed", self.source)

    def test_tool_installer_is_local_and_guards_archive_paths(self):
        self.assertIn("self.archive_path=Path(archive_path)", self.source)
        self.assertIn("zipfile.ZipFile", self.source)
        self.assertIn("win_member.is_absolute()", self.source)
        self.assertIn("stat.S_ISLNK(mode)", self.source)
        self.assertNotIn("requests.get(", self.source)
        self.assertNotIn("urllib.request.urlopen(", self.source)

    def test_device_calibration_profiles_and_autoresume_are_wired(self):
        self.assertIn('CFG.setdefault("calibration_profiles",{})[self.device]', self.source)
        self.assertIn('QTimer.singleShot(900, self._resume_stream_if_ready)', self.source)
        self.assertIn('Explicit disconnect cancels automatic stream resume', self.source)

    def test_reconnect_resume_really_invokes_stream_start(self):
        method = next(node for node in self.app_class.body
                      if isinstance(node, ast.FunctionDef) and node.name == "_resume_stream_if_ready")
        segment = ast.get_source_segment(self.source, method)
        self.assertIn("self.toggle_stream()", segment)
        self.assertIn("not self.connected or not self.device", segment)
        self.assertIn("self._resume_stream_after_reconnect=False", segment)

    def test_external_mirror_survives_technical_stream_restarts(self):
        self.assertIn('preserve_external=False', self.source)
        self.assertIn('and not preserve_external', self.source)
        self.assertIn('preserve_external=True', self.source)
        self.assertIn('preserve_external=self._resume_stream_after_reconnect', self.source)


if __name__ == "__main__":
    unittest.main()
