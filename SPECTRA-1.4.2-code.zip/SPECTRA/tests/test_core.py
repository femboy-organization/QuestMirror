import unittest
from spectra_core import (
    build_scrcpy_args, crop_rectangle, parse_adb_devices, parse_battery,
    parse_png_dimensions, parse_android_size, parse_scrcpy_fps, redact_ips, valid_ipv4,
    normalize_calibration, parse_android_ip, DEFAULT_CALIBRATION,
    calibration_adjustment, calibration_adjustment_limits, calibration_from_adjustment,
    parse_scrcpy_video_encoders,
)


class CoreTests(unittest.TestCase):
    def test_parse_adb_devices_keeps_states_and_model(self):
        rows = parse_adb_devices("""List of devices attached
abc123 device product:hollywood model:Quest_3 transport_id:2
192.168.1.7:5555 unauthorized transport_id:4
""")
        self.assertEqual(len(rows), 2)
        self.assertEqual(rows[0]["serial"], "abc123")
        self.assertEqual(rows[0]["model"], "Quest 3")
        self.assertEqual(rows[1]["state"], "unauthorized")

    def test_valid_ipv4(self):
        self.assertTrue(valid_ipv4("192.168.1.7"))
        self.assertFalse(valid_ipv4("999.168.1.7"))
        self.assertFalse(valid_ipv4("name.local"))

    def test_battery_parser(self):
        parsed = parse_battery("level: 87\ntemperature: 341\nUSB powered: true\n")
        self.assertEqual(parsed["level"], 87)
        self.assertEqual(parsed["temperature_c"], 34.1)
        self.assertEqual(parsed["plugged"], "USB")
        self.assertIsNone(parse_battery("other: 1")["level"])

    def test_parse_android_size_prefers_override_size(self):
        self.assertEqual(parse_android_size("Physical size: 4128x2208\nOverride size: 2064x2208"), (2064, 2208))
        self.assertEqual(parse_android_size("Physical size: 2064X2208"), (2064, 2208))
        self.assertIsNone(parse_android_size("not a resolution"))

    def test_parse_scrcpy_fps(self):
        self.assertEqual(parse_scrcpy_fps("INFO: FPS: 72.0"), 72.0)
        self.assertEqual(parse_scrcpy_fps("30.5 fps"), 30.5)
        self.assertIsNone(parse_scrcpy_fps("Video bitrate: 25 Mbps"))
        self.assertIsNone(parse_scrcpy_fps("FPS: 500"))

    def test_png_dimensions(self):
        data = b"\x89PNG\r\n\x1a\n" + b"\x00\x00\x00\rIHDR" + (640).to_bytes(4, "big") + (480).to_bytes(4, "big") + b"\x08\x02\x00\x00\x00"
        self.assertEqual(parse_png_dimensions(data), (640, 480))
        self.assertIsNone(parse_png_dimensions(b"not png"))

    def test_crop_rectangle_is_bounded(self):
        self.assertEqual(crop_rectangle((4128, 2208), "Правый"), (2064, 2208, 2064, 0))
        self.assertIsNone(crop_rectangle((1920, 1080), "Правый"))
        cropped = crop_rectangle((2064, 2208), "Левый", {"x": 100, "y": -100, "width": 50, "height": 50})
        self.assertIsNotNone(cropped)
        w, h, x, y = cropped
        self.assertLessEqual(x + w, 2064)
        self.assertLessEqual(y + h, 2208)

    def test_scrcpy_flags_adapt_to_help(self):
        args = build_scrcpy_args("scrcpy", "abc", "1080p", "30", 25, "SPECTRA", "--video-bit-rate --print-fps --window-borderless")
        self.assertIn("--video-bit-rate", args)
        self.assertIn("--print-fps", args)
        self.assertNotIn("--bit-rate", args)
        self.assertIn("--no-audio", args)
        modern = build_scrcpy_args("scrcpy", "abc", "720p", "24", 12, "SPECTRA")
        self.assertIn("--video-bit-rate", modern)
        self.assertIn("12M", modern)

    def test_scrcpy_encoder_list_parser_filters_to_h264_and_deduplicates(self):
        output = """INFO: List of video encoders:
    --video-codec=h264 --video-encoder=c2.qti.avc.encoder (hw) [vendor]
    --video-codec=h264 --video-encoder=c2.android.avc.encoder (sw) [Android]
    --video-codec=h265 --video-encoder=c2.qti.hevc.encoder (hw) [vendor]
    --video-codec=h264 --video-encoder=c2.qti.avc.encoder (hw) [vendor]
"""
        self.assertEqual(
            parse_scrcpy_video_encoders(output),
            ["c2.qti.avc.encoder", "c2.android.avc.encoder"],
        )

    def test_scrcpy_args_can_select_explicit_video_encoder(self):
        args = build_scrcpy_args(
            "scrcpy", "abc", "720p", "30", 16, "SPECTRA",
            "--video-bit-rate --video-encoder <name>", video_encoder="c2.qti.avc.encoder",
        )
        self.assertEqual(args[args.index("--video-encoder") + 1], "c2.qti.avc.encoder")
        with self.assertRaisesRegex(ValueError, "не поддерживает выбор видеокодера"):
            build_scrcpy_args("scrcpy", "abc", "720p", "30", 16, "SPECTRA", "--video-bit-rate", video_encoder="encoder")
        with self.assertRaisesRegex(ValueError, "Недопустимое имя"):
            build_scrcpy_args("scrcpy", "abc", "720p", "30", 16, "SPECTRA", video_encoder="bad encoder")

    def test_scrcpy_rotation_supports_arbitrary_angles_and_legacy_quarter_turns(self):
        modern = build_scrcpy_args(
            "scrcpy", "abc", "720p", "30", 16, "SPECTRA",
            "--angle <degrees> --display-orientation <value>", rotation=27,
        )
        self.assertEqual(modern[modern.index("--angle") + 1], "27")
        legacy = build_scrcpy_args(
            "scrcpy", "abc", "720p", "30", 16, "SPECTRA",
            "--rotation <value>", rotation=-90,
        )
        self.assertEqual(legacy[legacy.index("--rotation") + 1], "1")
        with self.assertRaisesRegex(ValueError, "только поворот на 90°"):
            build_scrcpy_args("scrcpy", "abc", "720p", "30", 16, "SPECTRA", "--rotation", rotation=33)

    def test_redaction(self):
        self.assertEqual(redact_ips("device 192.168.1.3:5555"), "device <IP>")

    def test_parse_android_ip_prefers_route_source_and_skips_loopback(self):
        self.assertEqual(parse_android_ip("default via 192.168.1.1 dev wlan0 src 192.168.1.42 metric 303"), "192.168.1.42")
        self.assertEqual(parse_android_ip("inet 127.0.0.1/8 scope host\ninet 10.0.0.25/24 scope global wlan0"), "10.0.0.25")
        self.assertIsNone(parse_android_ip("inet 127.0.0.1/8 scope host"))

    def test_normalize_calibration_clamps_values_and_handles_corruption(self):
        self.assertEqual(
            normalize_calibration({"x": 999, "y": -999, "width": 0, "height": "bad", "rotation": -999}),
            {"x": 100, "y": -100, "width": 10, "height": 40, "rotation": -180},
        )
        self.assertEqual(normalize_calibration(None), DEFAULT_CALIBRATION)

    def test_calibration_sliders_are_zero_based_on_standard_crop(self):
        self.assertEqual(DEFAULT_CALIBRATION, {"x": -16, "y": 0, "width": 77, "height": 40, "rotation": 0})
        for key, effective in DEFAULT_CALIBRATION.items():
            self.assertEqual(calibration_adjustment(key, effective), 0)
            self.assertEqual(calibration_from_adjustment(key, 0), effective)
        self.assertEqual(calibration_from_adjustment("x", 5), -11)
        self.assertEqual(calibration_from_adjustment("width", 5), 82)
        self.assertEqual(calibration_adjustment_limits("x"), (-84, 116))
        self.assertEqual(calibration_adjustment_limits("width"), (-67, 23))

    def test_crop_rectangle_bounds_for_varied_calibrations(self):
        sizes = [(2064, 2208), (4128, 2208), (1920, 1080), (3840, 2160)]
        profiles = [
            {"x": x, "y": y, "width": w, "height": h}
            for x, y, w, h in [(-100, -100, 10, 10), (100, 100, 100, 100), (0, 0, 50, 75)]
        ]
        for size in sizes:
            for profile in profiles:
                for eye in ("Правый", "Левый"):
                    rect = crop_rectangle(size, eye, profile)
                    if rect:
                        width, height, x, y = rect
                        self.assertGreater(width, 0)
                        self.assertGreater(height, 0)
                        self.assertGreaterEqual(x, 0)
                        self.assertGreaterEqual(y, 0)
                        self.assertLessEqual(x + width, size[0])
                        self.assertLessEqual(y + height, size[1])


if __name__ == "__main__":
    unittest.main()
