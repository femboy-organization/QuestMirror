"""Pure helper functions used by SPECTRA; intentionally requires only stdlib."""
from __future__ import annotations

import ipaddress
import re
from typing import Any


# Effective crop values used when calibration sliders are at their neutral (zero) position.
DEFAULT_CALIBRATION = {"x": -16, "y": 0, "width": 77, "height": 40, "rotation": 0}
CALIBRATION_LIMITS = {
    "x": (-100, 100), "y": (-100, 100), "width": (10, 100),
    "height": (10, 100), "rotation": (-180, 180),
}


def parse_adb_devices(output: str) -> list[dict[str, str]]:
    """Parse `adb devices -l`, preserving device states such as unauthorized/offline."""
    devices: list[dict[str, str]] = []
    for raw in (output or "").splitlines():
        line = raw.strip()
        if not line or line.lower().startswith("list of devices") or line.startswith("*"):
            continue
        parts = line.split()
        if len(parts) < 2:
            continue
        serial, state = parts[0], parts[1]
        attrs: dict[str, str] = {}
        for part in parts[2:]:
            if ":" in part:
                key, value = part.split(":", 1)
                attrs[key] = value
        raw_model = attrs.get("model", "")
        model = raw_model.replace("_", " ").strip() or "Android device"
        devices.append({
            "serial": serial,
            "state": state,
            "model": model,
            "product": attrs.get("product", ""),
            "transport_id": attrs.get("transport_id", ""),
        })
    return devices


def valid_ipv4(value: str) -> bool:
    try:
        ipaddress.IPv4Address((value or "").strip())
        return True
    except ipaddress.AddressValueError:
        return False



def parse_android_ip(output: str) -> str | None:
    """Find a usable IPv4 from Android `ip route` or `ip addr` output."""
    text = str(output or "")
    candidates: list[str] = []
    # The route's `src` is the address actually used by the Wi-Fi default route.
    candidates.extend(re.findall(r"\bsrc\s+((?:\d{1,3}\.){3}\d{1,3})\b", text, re.I))
    candidates.extend(re.findall(r"\binet\s+((?:\d{1,3}\.){3}\d{1,3})(?:/\d{1,2})?\b", text, re.I))
    for candidate in candidates:
        if not valid_ipv4(candidate):
            continue
        if candidate.startswith(("127.", "169.254.")) or candidate == "0.0.0.0":
            continue
        return candidate
    return None

def parse_battery(output: str) -> dict[str, Any]:
    """Return available battery fields from `dumpsys battery`; unknowns stay None."""
    result: dict[str, Any] = {"level": None, "temperature_c": None, "plugged": None}
    for line in (output or "").splitlines():
        match = re.match(r"\s*(level|temperature|AC powered|USB powered|Wireless powered)\s*:\s*(.+?)\s*$", line, re.I)
        if not match:
            continue
        key, value = match.group(1).lower(), match.group(2)
        if key == "level":
            try:
                level = int(value)
                if 0 <= level <= 100:
                    result["level"] = level
            except ValueError:
                pass
        elif key == "temperature":
            try:
                temperature = int(value) / 10.0
                if -20 <= temperature <= 100:
                    result["temperature_c"] = temperature
            except ValueError:
                pass
        elif key in {"ac powered", "usb powered", "wireless powered"} and value.lower() in {"true", "false"}:
            if value.lower() == "true":
                result["plugged"] = key.removesuffix(" powered").upper()
            elif result["plugged"] is None:
                result["plugged"] = "Нет"
    return result


def parse_android_size(output: str) -> tuple[int, int] | None:
    """Parse `adb shell wm size` output, preferring the last (effective) dimensions."""
    matches = re.findall(r"(?:Physical|Override)?\s*size\s*:\s*(\d{2,5})\s*[xX×]\s*(\d{2,5})", output or "", re.I)
    if not matches:
        # Some Android/OEM builds return only a bare resolution.
        matches = re.findall(r"(?<!\d)(\d{2,5})\s*[xX×]\s*(\d{2,5})(?!\d)", output or "")
    for width_text, height_text in reversed(matches):
        width, height = int(width_text), int(height_text)
        if 100 <= width <= 20000 and 100 <= height <= 20000:
            return width, height
    return None


def parse_scrcpy_fps(output: str) -> float | None:
    """Parse explicit FPS output from scrcpy, returning None for unrelated logs."""
    text = str(output or "")
    match = re.search(r"\bfps\s*[:=]?\s*([0-9]+(?:\.[0-9]+)?)\b", text, re.I)
    if not match:
        match = re.search(r"\b([0-9]+(?:\.[0-9]+)?)\s*fps\b", text, re.I)
    if not match:
        return None
    try:
        value = float(match.group(1))
    except (ValueError, TypeError):
        return None
    return value if 0 <= value <= 240 else None


def parse_png_dimensions(data: bytes) -> tuple[int, int] | None:
    """Read PNG width/height from the IHDR; returns None for non-PNG data."""
    if len(data) < 24 or not data.startswith(b"\x89PNG\r\n\x1a\n") or data[12:16] != b"IHDR":
        return None
    width = int.from_bytes(data[16:20], "big")
    height = int.from_bytes(data[20:24], "big")
    if width < 1 or height < 1 or width > 20000 or height > 20000:
        return None
    return width, height


def parse_scrcpy_video_encoders(output: str, codec: str = "h264") -> list[str]:
    """Extract compatible encoder names from scrcpy --list-encoders output."""
    names: list[str] = []
    wanted_codec = str(codec or "h264").strip().lower()
    for line in str(output or "").splitlines():
        match = re.search(r"--video-encoder(?:=|\s+)([^\s,]+)", line)
        if not match:
            continue
        codec_match = re.search(r"--video-codec(?:=|\s+)([^\s,]+)", line)
        if codec_match and codec_match.group(1).strip().lower() != wanted_codec:
            continue
        name = match.group(1).strip().strip('"\'')
        if re.fullmatch(r"[A-Za-z0-9._-]{1,120}", name) and name not in names:
            names.append(name)
    return names


def build_scrcpy_args(
    executable: str,
    serial: str,
    resolution: str,
    fps: str | int,
    bitrate: int,
    window_title: str,
    help_text: str = "",
    crop: str | None = None,
    rotation: int = 0,
    video_encoder: str = "",
) -> list[str]:
    """Build a command compatible with more than one scrcpy CLI generation."""
    help_text = help_text or ""
    args = [executable, "--serial", serial, "--no-audio"]
    args += ["--max-size", str({"720p": 1280, "1080p": 1920, "1440p": 2560}.get(str(resolution), 1920))]
    args += ["--max-fps", str(int(fps))]
    if "--video-bit-rate" in help_text:
        bitrate_flag = "--video-bit-rate"
    elif "--bit-rate" in help_text:
        bitrate_flag = "--bit-rate"
    else:
        # Modern official scrcpy builds use --video-bit-rate. Prefer this flag
        # when a restricted/older CLI fails to return its help text.
        bitrate_flag = "--video-bit-rate"
    args += [bitrate_flag, f"{int(bitrate)}M", "--window-title", window_title]
    encoder = str(video_encoder or "").strip()
    if encoder:
        if help_text and "--video-encoder" not in help_text:
            raise ValueError(
                "Эта версия scrcpy не поддерживает выбор видеокодера. "
                "Обновите scrcpy или верните режим «Автоматически»."
            )
        if not re.fullmatch(r"[A-Za-z0-9._-]{1,120}", encoder):
            raise ValueError("Недопустимое имя видеокодера.")
        args += ["--video-encoder", encoder]
    if "--window-borderless" in help_text:
        args.append("--window-borderless")
    if "--print-fps" in help_text:
        args.append("--print-fps")
    if crop:
        args += ["--crop", crop]

    # Prefer client-side rotation where supported. Older scrcpy versions expose
    # --rotation in quarter-turn units (0, 1=CCW, 2=180, 3=CW).
    angle = max(-180, min(180, int(rotation)))
    if angle:
        if "--angle" in help_text:
            args += ["--angle", str(angle)]
        elif angle % 90 == 0:
            degrees = angle % 360
            if "--display-orientation" in help_text:
                args += ["--display-orientation", str(degrees)]
            elif "--orientation" in help_text:
                args += ["--orientation", str(degrees)]
            elif "--capture-orientation" in help_text:
                args += ["--capture-orientation", str(degrees)]
            elif "--rotation" in help_text:
                legacy_rotation = {0: 0, 90: 3, 180: 2, 270: 1}[degrees]
                args += ["--rotation", str(legacy_rotation)]
            else:
                raise ValueError(
                    "Эта версия scrcpy не поддерживает поворот изображения. "
                    "Установите более новую версию scrcpy и повторите попытку."
                )
        else:
            raise ValueError(
                "Эта версия scrcpy поддерживает только поворот на 90°, 180° или 270°. "
                "Для произвольного угла установите более новую версию scrcpy."
            )
    return args



def calibration_adjustment(key: str, effective_value: int) -> int:
    """Convert an effective calibration value to a slider adjustment from the base profile."""
    value = int(effective_value)
    return value if key == "rotation" else value - DEFAULT_CALIBRATION.get(key, 0)


def calibration_from_adjustment(key: str, adjustment: int) -> int:
    """Convert a zero-based slider adjustment to the effective calibration value."""
    if key not in CALIBRATION_LIMITS:
        raise KeyError(key)
    low, high = CALIBRATION_LIMITS[key]
    base = DEFAULT_CALIBRATION[key]
    value = int(adjustment) if key == "rotation" else base + int(adjustment)
    return max(low, min(high, value))


def calibration_adjustment_limits(key: str) -> tuple[int, int]:
    """Return valid slider limits, with zero meaning the standard calibration value."""
    if key not in CALIBRATION_LIMITS:
        raise KeyError(key)
    low, high = CALIBRATION_LIMITS[key]
    base = DEFAULT_CALIBRATION[key]
    return (low, high) if key == "rotation" else (low - base, high - base)


def normalize_calibration(values: Any) -> dict[str, int]:
    """Return a bounded calibration profile with safe defaults for corrupt settings."""
    source = values if isinstance(values, dict) else {}
    result: dict[str, int] = {}
    for key, (low, high) in CALIBRATION_LIMITS.items():
        default = DEFAULT_CALIBRATION[key]
        try:
            result[key] = max(low, min(high, int(source.get(key, default))))
        except (TypeError, ValueError, OverflowError):
            result[key] = default
    return result

def crop_rectangle(
    source_size: tuple[int, int],
    eye: str = "Правый",
    calibration: dict[str, int] | None = None,
) -> tuple[int, int, int, int] | None:
    """Compute a bounded scrcpy crop; eye crop is used only for side-by-side sources."""
    width, height = source_size
    if width <= 0 or height <= 0:
        return None
    x0, y0, w, h = 0, 0, width, height
    # A wide aspect ratio alone also matches ordinary 16:9 screens; require a
    # high horizontal resolution to avoid accidentally cropping a regular display.
    if width >= 3000 and width >= height * 1.5:
        w = width // 2
        x0 = w if eye == "Правый" else 0
    cal = calibration or {"x": 0, "y": 0, "width": 100, "height": 100, "rotation": 0}
    width_pct = max(10, min(150, int(cal.get("width", 100))))
    height_pct = max(10, min(150, int(cal.get("height", 100))))
    offset_x_pct = max(-100, min(100, int(cal.get("x", 0))))
    offset_y_pct = max(-100, min(100, int(cal.get("y", 0))))
    new_w = max(1, min(w, round(w * min(width_pct, 100) / 100)))
    new_h = max(1, min(h, round(h * min(height_pct, 100) / 100)))
    spare_x, spare_y = w - new_w, h - new_h
    x0 += round(spare_x / 2 + spare_x / 2 * offset_x_pct / 100)
    y0 += round(spare_y / 2 + spare_y / 2 * offset_y_pct / 100)
    # scrcpy crop values must stay within the source frame.
    x0 = max(0, min(width - new_w, x0))
    y0 = max(0, min(height - new_h, y0))
    if (new_w, new_h, x0, y0) == (width, height, 0, 0):
        return None
    return new_w, new_h, x0, y0


def redact_ips(text: str) -> str:
    """Redact ordinary IPv4 literals from diagnostics before sharing."""
    return re.sub(r"\b(?:\d{1,3}\.){3}\d{1,3}(?::\d+)?\b", "<IP>", str(text))
