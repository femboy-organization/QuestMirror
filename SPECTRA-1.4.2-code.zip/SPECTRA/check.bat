@echo off
setlocal EnableExtensions
cd /d "%~dp0"
chcp 65001 >nul
title SPECTRA - Source Checks

echo ==========================================
echo SPECTRA - SOURCE / REGRESSION CHECKS
echo ==========================================
where py >nul 2>&1
if not errorlevel 1 goto USE_PY
where python >nul 2>&1
if not errorlevel 1 goto USE_PYTHON

echo ERROR: Python was not found. Install Python 3.11+.
pause
exit /b 1

:USE_PY
echo Compiling source files...
py -3 -m compileall -q app.py spectra_core.py tests
if errorlevel 1 goto FAILED
echo Running regression tests...
py -3 -m unittest discover -s tests -v
if errorlevel 1 goto FAILED
goto PASSED

:USE_PYTHON
echo Compiling source files...
python -m compileall -q app.py spectra_core.py tests
if errorlevel 1 goto FAILED
echo Running regression tests...
python -m unittest discover -s tests -v
if errorlevel 1 goto FAILED

:PASSED
echo.
echo ALL SOURCE CHECKS PASSED.
pause
exit /b 0

:FAILED
echo.
echo CHECKS FAILED. Send the full output for diagnosis.
pause
exit /b 1
