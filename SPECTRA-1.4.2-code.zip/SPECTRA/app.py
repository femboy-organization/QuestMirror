import sys, os, json, subprocess, shutil, time, socket, threading, re, logging, traceback, zipfile, ctypes, platform, copy
from pathlib import Path
from datetime import datetime
from logging.handlers import RotatingFileHandler

# Set up paths and diagnostics BEFORE importing Qt so startup errors are logged too.
APP_VERSION = "1.4.2"
APP_DIR = Path(__file__).resolve().parent
CONFIG_DIR = APP_DIR / "config"
LOG_DIR = APP_DIR / "logs"
CONFIG_PATH = CONFIG_DIR / "settings.json"
REQUIREMENTS_PATH = APP_DIR / "requirements.txt"
ADB = APP_DIR / "adb" / "adb.exe"
SCRCPY = APP_DIR / "scrcpy" / "scrcpy.exe"
for d in (CONFIG_DIR, LOG_DIR):
    d.mkdir(parents=True, exist_ok=True)

class RedactingFormatter(logging.Formatter):
    """Mask IPv4 addresses in logs before they are written or displayed."""
    def format(self, record):
        rendered = super().format(record)
        return redact_ips(rendered)

LOGGER = logging.getLogger("SPECTRA")
LOGGER.setLevel(logging.DEBUG)
if not LOGGER.handlers:
    _file_handler = RotatingFileHandler(
        LOG_DIR / "spectra.log", maxBytes=2 * 1024 * 1024, backupCount=4, encoding="utf-8"
    )
    _file_handler.setFormatter(RedactingFormatter(
        "%(asctime)s [%(levelname)s] [%(name)s] %(message)s", datefmt="%Y-%m-%d %H:%M:%S"
    ))
    LOGGER.addHandler(_file_handler)
    _console_handler = logging.StreamHandler()
    _console_handler.setFormatter(RedactingFormatter("[%(levelname)s] %(message)s"))
    LOGGER.addHandler(_console_handler)


def _report_missing_pyside6():
    """Explain the missing GUI dependency without performing an implicit network request."""
    message = (
        "PySide6 не установлен в выбранном Python.\n"
        "Запустите run.bat из папки SPECTRA — он проверит окружение и установит зависимости.\n"
        "Либо вручную выполните: python -m pip install -r requirements.txt\n"
        f"Подробности: {LOG_DIR / 'spectra.log'}"
    )
    LOGGER.critical(message.replace("\n", " | "))
    print("\n" + message + "\n")
    try:
        input("Нажмите Enter для выхода…")
    except EOFError:
        pass
    raise SystemExit(1)

from spectra_core import (
    parse_adb_devices, parse_battery, valid_ipv4, parse_png_dimensions, parse_android_size,
    build_scrcpy_args, crop_rectangle, redact_ips, parse_scrcpy_fps, normalize_calibration, parse_android_ip,
    DEFAULT_CALIBRATION, calibration_adjustment, calibration_adjustment_limits, calibration_from_adjustment,
    parse_scrcpy_video_encoders,
)

try:
    from PySide6.QtCore import Qt, QTimer, Signal, QObject, QThread, QRect
    from PySide6.QtGui import QFont, QAction, QKeySequence, QShortcut, QWindow, QPixmap
    from PySide6.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
        QLabel, QPushButton, QFrame, QStackedWidget, QTabWidget, QLineEdit, QComboBox,
        QCheckBox, QSlider, QTextEdit, QListWidget, QListWidgetItem, QMessageBox, QDialog,
        QFormLayout, QSpinBox, QGroupBox, QGridLayout, QSplitter, QProgressBar, QFileDialog)
except ModuleNotFoundError as exc:
    if (exc.name or "").split(".")[0] == "PySide6":
        _report_missing_pyside6()
    LOGGER.exception("Ошибка импорта обязательного модуля при запуске")
    raise
except Exception:
    LOGGER.exception("Ошибка импорта PySide6")
    raise

DEFAULTS = {
    "language":"RU", "first_run":True, "last_ip":"", "saved_headsets":[],
    "resolution":"720p", "fps":"30", "eye":"Правый", "bitrate":16, "video_encoder":"",
    "auto_bitrate":False, "auto_reconnect":True, "keep_awake":False,
    "keep_awake_originals": {},
    "osd":{"live":True,"mode":True,"metrics":True,"eye":True,"clock":True,"position":"Правый верх"},
    "calibration":dict(DEFAULT_CALIBRATION),
    "calibration_profiles":{},
    "external_fit":"Fit"
}
def load_config():
    try:
        data=json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
        if not isinstance(data, dict):
            raise ValueError("Корневое значение settings.json должно быть объектом")
        merged = {**DEFAULTS, **data}
        for nested in ("osd", "calibration"):
            if not isinstance(merged.get(nested), dict):
                merged[nested] = DEFAULTS[nested].copy()
            else:
                merged[nested] = {**DEFAULTS[nested], **merged[nested]}
        if merged.get("resolution") not in {"720p", "1080p", "1440p"}: merged["resolution"] = DEFAULTS["resolution"]
        if str(merged.get("fps")) not in {"24", "30", "60"}: merged["fps"] = DEFAULTS["fps"]
        if merged.get("eye") not in {"Правый", "Левый"}: merged["eye"] = DEFAULTS["eye"]
        encoder = str(merged.get("video_encoder", "") or "").strip()
        merged["video_encoder"] = encoder if re.fullmatch(r"[A-Za-z0-9._-]{1,120}", encoder) else ""
        if merged.get("external_fit") not in {"Fit", "Fill", "Stretch"}: merged["external_fit"] = DEFAULTS["external_fit"]
        if merged["osd"].get("position") not in {"Левый верх", "Правый верх", "Левый низ", "Правый низ"}:
            merged["osd"]["position"] = DEFAULTS["osd"]["position"]
        try: merged["bitrate"] = max(5, min(40, int(merged.get("bitrate", 16))))
        except (TypeError, ValueError): merged["bitrate"] = DEFAULTS["bitrate"]
        merged["calibration"] = normalize_calibration(merged.get("calibration"))
        profiles = merged.get("calibration_profiles", {})
        if not isinstance(profiles, dict):
            profiles = {}
        merged["calibration_profiles"] = {
            str(serial): normalize_calibration(profile)
            for serial, profile in profiles.items()
            if str(serial).strip() and isinstance(profile, dict)
        }
        for key in ("auto_reconnect", "keep_awake"):
            if not isinstance(merged.get(key), bool): merged[key] = DEFAULTS[key]
        merged["auto_bitrate"] = False  # Not implemented; never preserve a misleading enabled state.
        if not isinstance(merged.get("saved_headsets"), list): merged["saved_headsets"] = []
        merged["last_ip"] = str(merged.get("last_ip", "")).strip()
        if merged["last_ip"] and not valid_ipv4(merged["last_ip"]): merged["last_ip"] = ""
        originals = merged.get("keep_awake_originals", {})
        if not isinstance(originals, dict): originals = {}
        merged["keep_awake_originals"] = {str(k): str(v) for k, v in originals.items()
            if str(k).strip() and str(v).isdigit() and len(str(v)) <= 3}
        LOGGER.info("Настройки загружены из %s", CONFIG_PATH)
        return merged
    except FileNotFoundError:
        LOGGER.info("Файл настроек ещё не создан; используются значения по умолчанию")
        return copy.deepcopy(DEFAULTS)
    except Exception:
        LOGGER.exception("Не удалось прочитать настройки; используются значения по умолчанию")
        # Preserve a malformed file for post-mortem instead of silently destroying user data.
        try:
            if CONFIG_PATH.is_file():
                backup=CONFIG_DIR/("settings.corrupt-"+datetime.now().strftime("%Y%m%d-%H%M%S")+".json")
                shutil.copy2(CONFIG_PATH,backup)
                LOGGER.warning("Повреждённые настройки сохранены отдельно: %s",backup.name)
        except Exception:
            LOGGER.exception("Не удалось сохранить резервную копию повреждённых настроек")
        return copy.deepcopy(DEFAULTS)
CFG=load_config()

class Bus(QObject):
    log = Signal(str, str)
BUS=Bus()

def resolve_binary(name: str) -> str | None:
    """Resolve bundled executables, the bundled scrcpy/ADB pair, then PATH."""
    if name.lower() == "adb":
        candidates=(SCRCPY.parent/"adb.exe", ADB)
    else:
        candidates=(SCRCPY,)
    for candidate in candidates:
        if candidate.is_file(): return str(candidate)
    return shutil.which(name)

class DeviceScanWorker(QThread):
    completed = Signal(object, str, float)
    def __init__(self, adb_path: str | None, auto_ip: str = "", auto_reconnect: bool = False, parent=None):
        super().__init__(parent)
        self.adb_path = adb_path
        self.auto_ip = auto_ip.strip()
        self.auto_reconnect = auto_reconnect
    def run(self):
        start = time.perf_counter()
        if self.isInterruptionRequested():
            self.completed.emit([], "Сканирование отменено", 0.0); return
        if not self.adb_path:
            self.completed.emit([], "ADB не найден", 0.0); return
        try:
            run = subprocess.run([self.adb_path, "devices", "-l"], capture_output=True, text=True, timeout=6,
                encoding="utf-8", errors="replace", creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
            stdout = (run.stdout or "").strip()
            stderr = (run.stderr or "").strip()
            output = (stdout + ("\n" + stderr if stderr else "")).strip()
            devices = parse_adb_devices(stdout) if run.returncode == 0 else []
            if run.returncode != 0:
                self.completed.emit(devices, output or f"ADB exit code {run.returncode}", time.perf_counter()-start); return
            if self.auto_reconnect and valid_ipv4(self.auto_ip) and not self.isInterruptionRequested():
                known = {d["serial"] for d in devices if d.get("state") == "device"}
                serial = self.auto_ip + ":5555"
                if serial not in known:
                    try:
                        if self.isInterruptionRequested():
                            self.completed.emit(devices, "Сканирование отменено", time.perf_counter()-start); return
                        subprocess.run([self.adb_path, "connect", serial], capture_output=True, text=True, timeout=5,
                            encoding="utf-8", errors="replace", creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
                        run2 = subprocess.run([self.adb_path, "devices", "-l"], capture_output=True, text=True, timeout=6,
                            encoding="utf-8", errors="replace", creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
                        if run2.returncode == 0:
                            output = (run2.stdout or "").strip()
                            devices = parse_adb_devices(output)
                    except Exception:
                        pass
            self.completed.emit(devices, "", time.perf_counter()-start)
        except Exception as exc:
            self.completed.emit([], f"{type(exc).__name__}: {exc}", time.perf_counter()-start)

class WifiConnectWorker(QThread):
    """Connect over classic ADB TCP/IP; may discover the Wi-Fi IPv4 over USB first."""
    progress = Signal(str)
    completed = Signal(bool, str, str)  # success, output, resolved IPv4 address

    def __init__(self, adb_path: str, address: str = "", usb_serial: str = "", parent=None):
        super().__init__(parent)
        self.adb_path = adb_path
        self.address = str(address or "").strip()
        self.usb_serial = str(usb_serial or "").strip()

    def _run_adb(self, args, timeout=6):
        result = subprocess.run([self.adb_path, *args], capture_output=True, text=True,
            timeout=timeout, encoding="utf-8", errors="replace",
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        output = (result.stdout + "\n" + result.stderr).strip()
        return result.returncode, output

    def _discover_wifi_address(self):
        if not self.usb_serial or ":" in self.usb_serial:
            return ""
        commands = [
            ["-s", self.usb_serial, "shell", "ip", "route"],
            ["-s", self.usb_serial, "shell", "ip", "-f", "inet", "addr", "show", "wlan0"],
            ["-s", self.usb_serial, "shell", "ip", "-f", "inet", "addr", "show"],
        ]
        for command in commands:
            if self.isInterruptionRequested():
                return ""
            try:
                code, output = self._run_adb(command, timeout=4)
                candidate = parse_android_ip(output) if code == 0 else None
                if candidate:
                    return candidate
            except Exception:
                LOGGER.debug("Не удалось получить IP через команду ADB %s", command[3:], exc_info=True)
        return ""

    def run(self):
        address=self.address
        try:
            if self.isInterruptionRequested():
                self.completed.emit(False,"Подключение отменено при завершении приложения.",address); return
            if address and not valid_ipv4(address):
                self.completed.emit(False,"Введён некорректный IPv4-адрес.",address); return
            if not address and self.usb_serial and ":" not in self.usb_serial:
                self.progress.emit("Определяю IP шлема по USB через таблицу маршрутов Android…")
                address=self._discover_wifi_address()
                if not address:
                    self.completed.emit(False,"Не удалось автоматически определить IP шлема. Проверьте, что Wi-Fi подключён, либо введите адрес вручную.",""); return
                self.address=address
                self.progress.emit("Найден IP шлема; переключаю ADB в режим TCP/IP…")
            if not address:
                self.completed.emit(False,"Введите IP шлема или подключите его по USB для автоматического определения адреса.",""); return
            if self.usb_serial and ":" not in self.usb_serial:
                self.progress.emit("Включаю ADB по TCP/IP через USB…")
                code, output = self._run_adb(["-s", self.usb_serial, "tcpip", "5555"])
                low = output.lower()
                if code != 0 and "restarting in tcp mode" not in low:
                    self.progress.emit("Команда TCP/IP: " + (output or f"код {code}"))
                for _ in range(15):
                    if self.isInterruptionRequested():
                        self.completed.emit(False,"Подключение отменено при завершении приложения.",address); return
                    time.sleep(0.1)
            serial = address + ":5555"
            last = "Нет ответа от ADB"
            for attempt in range(1, 5):
                if self.isInterruptionRequested():
                    self.completed.emit(False,"Подключение отменено при завершении приложения.",address); return
                self.progress.emit(f"Подключение к {serial} (попытка {attempt}/4)…")
                code, output = self._run_adb(["connect", serial], timeout=4)
                low = output.lower()
                if code == 0 and ("connected to" in low or "already connected" in low):
                    self.completed.emit(True, output or "ADB сообщил об успешном подключении.", address)
                    return
                last = output or f"ADB завершился с кодом {code}"
                if attempt < 4:
                    for _ in range(14):
                        if self.isInterruptionRequested():
                            self.completed.emit(False,"Подключение отменено при завершении приложения.",address); return
                        time.sleep(0.1)
            self.completed.emit(False, last + "\n\nПроверьте, что шлем и компьютер в одной сети, USB debugging подтверждён, а TCP/IP-порт 5555 доступен.",address)
        except Exception as exc:
            LOGGER.exception("Ошибка при подключении ADB по Wi-Fi")
            self.completed.emit(False, f"{type(exc).__name__}: {exc}", address)

class MetricsWorker(QThread):
    completed = Signal(str, object, str)
    def __init__(self, adb_path: str | None, serial: str, parent=None):
        super().__init__(parent)
        self.adb_path, self.serial = adb_path, serial
    def run(self):
        if self.isInterruptionRequested():
            self.completed.emit(self.serial, {}, "Сбор метрик отменён"); return
        if not self.adb_path or not self.serial:
            self.completed.emit(self.serial, {}, "ADB or device unavailable"); return
        values = {"latency_ms": None, "battery": {"level": None, "temperature_c": None, "plugged": None}, "state": None}
        try:
            start = time.perf_counter()
            state = subprocess.run([self.adb_path, "-s", self.serial, "get-state"], capture_output=True, text=True, timeout=4,
                encoding="utf-8", errors="replace", creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
            values["latency_ms"] = round((time.perf_counter()-start)*1000, 1)
            values["state"] = state.stdout.strip() if state.returncode == 0 else "offline"
            if state.returncode == 0:
                battery = subprocess.run([self.adb_path, "-s", self.serial, "shell", "dumpsys", "battery"], capture_output=True, text=True, timeout=5,
                    encoding="utf-8", errors="replace", creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
                if battery.returncode == 0:
                    values["battery"] = parse_battery(battery.stdout)
                self.completed.emit(self.serial, values, "")
            else:
                self.completed.emit(self.serial, values, state.stderr.strip() or state.stdout.strip() or "Устройство не отвечает")
        except Exception as exc:
            self.completed.emit(self.serial, values, f"{type(exc).__name__}: {exc}")

class ScrcpyOutputReader(QThread):
    line_received = Signal(str)
    def __init__(self, process, log_path: Path, title: str, parent=None):
        super().__init__(parent)
        self.process, self.log_path, self.title = process, log_path, title
    def run(self):
        try:
            if self.log_path.exists() and self.log_path.stat().st_size > 10 * 1024 * 1024:
                old=self.log_path.with_suffix(self.log_path.suffix+".1")
                try: old.unlink(missing_ok=True)
                except Exception: pass
                self.log_path.replace(old)
            with self.log_path.open("a", encoding="utf-8", errors="replace") as handle:
                handle.write(f"\n--- scrcpy start {stamp()} ---\nWINDOW: {self.title}\n")
                handle.flush()
                stream = self.process.stdout
                if stream is not None:
                    for line in iter(stream.readline, ""):
                        safe_line=redact_ips(line)
                        handle.write(safe_line); handle.flush()
                        self.line_received.emit(safe_line.rstrip())
                handle.write(f"\n--- scrcpy output ended {stamp()} ---\n")
        except Exception:
            LOGGER.exception("Ошибка чтения вывода scrcpy")

class ToolsInstallWorker(QThread):
    progress = Signal(str)
    completed = Signal(bool, str)

    def __init__(self, app_dir: Path, archive_path: Path, parent=None):
        super().__init__(parent)
        self.app_dir=Path(app_dir)
        self.archive_path=Path(archive_path)

    def run(self):
        """Safely install an explicitly selected local official scrcpy Windows x64 ZIP.

        This worker intentionally has no network code: the user obtains the ZIP in a
        browser and selects it. That preserves the project requirement of no app
        initiated external requests.
        """
        stage=self.app_dir/"scrcpy.installing"
        try:
            import hashlib, stat, tempfile, zipfile
            archive_path=self.archive_path.resolve(strict=True)
            if not archive_path.is_file():
                raise RuntimeError("Выбранный путь не является файлом.")
            if not re.fullmatch(r"scrcpy-win64-v[^/\\]+\.zip",archive_path.name,re.I):
                raise RuntimeError("Ожидается официальный архив с именем вида scrcpy-win64-vX.Y.Z.zip. Скачайте именно Windows x64 ZIP из официального релиза scrcpy.")
            archive_size=archive_path.stat().st_size
            if archive_size<=0 or archive_size>120*1024*1024:
                raise RuntimeError("Размер архива пуст или превышает безопасный лимит 120 МБ.")
            self.progress.emit("Проверяю локальный архив и вычисляю SHA-256…")
            digest=hashlib.sha256()
            with archive_path.open("rb") as stream:
                while True:
                    if self.isInterruptionRequested():
                        raise RuntimeError("Установка отменена при завершении приложения.")
                    chunk=stream.read(1024*1024)
                    if not chunk: break
                    digest.update(chunk)
            digest_hex=digest.hexdigest()
            target=self.app_dir/"scrcpy"
            backup=self.app_dir/"scrcpy.previous"
            if stage.exists(): shutil.rmtree(stage,ignore_errors=True)
            stage.mkdir(parents=True,exist_ok=True)
            try:
                with tempfile.TemporaryDirectory(prefix="spectra-tools-") as tmp:
                    temp=Path(tmp).resolve()
                    with zipfile.ZipFile(archive_path,"r") as zf:
                        infos=zf.infolist()
                        if not infos or len(infos)>2000:
                            raise RuntimeError("Архив пуст или содержит слишком много записей.")
                        total_size=sum(max(0,info.file_size) for info in infos)
                        if total_size>350*1024*1024:
                            raise RuntimeError("Распакованный архив превышает безопасный лимит 350 МБ.")
                        for info in infos:
                            if self.isInterruptionRequested():
                                raise RuntimeError("Установка отменена при завершении приложения.")
                            name=info.filename.replace("\\","/")
                            win_member=__import__("pathlib").PureWindowsPath(name)
                            posix_parts=Path(name).parts
                            if (not name or name.startswith("/") or win_member.is_absolute() or win_member.drive
                                    or ".." in posix_parts or ".." in win_member.parts):
                                raise RuntimeError("В архиве найден небезопасный путь.")
                            mode=(info.external_attr>>16)&0xFFFF
                            if stat.S_ISLNK(mode):
                                raise RuntimeError("Символические ссылки в архиве не разрешены.")
                            dest=(temp/Path(*[part for part in name.split("/") if part])).resolve()
                            if dest!=temp and temp not in dest.parents:
                                raise RuntimeError("Запись архива выходит за пределы временной папки.")
                            if info.is_dir():
                                dest.mkdir(parents=True,exist_ok=True); continue
                            if info.file_size>100*1024*1024:
                                raise RuntimeError("Файл внутри архива превышает лимит размера.")
                            dest.parent.mkdir(parents=True,exist_ok=True)
                            with zf.open(info,"r") as src, dest.open("wb") as dst:
                                shutil.copyfileobj(src,dst)
                    candidates=list(temp.rglob("scrcpy.exe"))
                    if not candidates:
                        raise RuntimeError("В архиве не найден scrcpy.exe.")
                    # Prefer the official distribution directory containing its matching ADB executable.
                    exe=next((x for x in candidates if (x.parent/"adb.exe").is_file()),None)
                    if exe is None:
                        raise RuntimeError("В архиве не найден adb.exe рядом с scrcpy.exe.")
                    source_dir=exe.parent
                    copy_count=0
                    for item in source_dir.iterdir():
                        if item.is_file():
                            shutil.copy2(item,stage/item.name); copy_count+=1
                if self.isInterruptionRequested():
                    raise RuntimeError("Установка отменена при завершении приложения.")
                if not (stage/"scrcpy.exe").is_file() or not (stage/"adb.exe").is_file():
                    raise RuntimeError("В подготовленной папке отсутствует scrcpy.exe или adb.exe.")
                # ADB server may lock its binaries on Windows; stop bundled and legacy ADB services first.
                old_adb_candidates=(target/"adb.exe",self.app_dir/"adb"/"adb.exe")
                for old_adb in old_adb_candidates:
                    if not old_adb.is_file(): continue
                    self.progress.emit("Останавливаю ADB-сервер перед заменой инструментов…")
                    try:
                        subprocess.run([str(old_adb),"kill-server"],capture_output=True,text=True,timeout=6,
                            encoding="utf-8",errors="replace",creationflags=getattr(subprocess,"CREATE_NO_WINDOW",0))
                    except Exception:
                        LOGGER.warning("Не удалось остановить ADB-сервер перед установкой",exc_info=True)
                if self.isInterruptionRequested():
                    raise RuntimeError("Установка отменена при завершении приложения.")
                if backup.exists(): shutil.rmtree(backup,ignore_errors=True)
                had_old=target.exists()
                if had_old: os.replace(target,backup)
                try:
                    os.replace(stage,target)
                except Exception:
                    if had_old and backup.exists() and not target.exists():
                        os.replace(backup,target)
                    raise
                if backup.exists(): shutil.rmtree(backup,ignore_errors=True)
                self.progress.emit(f"Инструменты установлены из {archive_path.name}; файлов: {copy_count}.")
            finally:
                if stage.exists(): shutil.rmtree(stage,ignore_errors=True)
            self.completed.emit(True,f"Установка завершена из локального архива.\nФайл: {archive_path.name}\nSHA-256: {digest_hex}\nФайлы: {target}\n\nПримечание: приложение не проверяет SHA-256 через сеть; при необходимости сравните хэш с опубликованным источником релиза.")
        except Exception as exc:
            LOGGER.exception("Установка ADB/scrcpy из локального архива не удалась")
            self.completed.emit(False,f"{type(exc).__name__}: {exc}")

class StreamPrepWorker(QThread):
    completed = Signal(object, str)

    def __init__(self, adb_path, scrcpy_path, serial, resolution, fps, bitrate, eye, calibration, video_encoder="", parent=None):
        super().__init__(parent)
        self.adb_path=adb_path; self.scrcpy_path=scrcpy_path; self.serial=serial
        self.resolution=resolution; self.fps=fps; self.bitrate=bitrate
        self.eye=eye; self.calibration=normalize_calibration(calibration); self.video_encoder=str(video_encoder or "").strip()
        self.title="SPECTRA-LIVE-"+str(int(time.time()*1000))

    def run(self):
        try:
            flags=getattr(subprocess,"CREATE_NO_WINDOW",0)
            state=subprocess.run([self.adb_path,"-s",self.serial,"get-state"],capture_output=True,text=True,
                timeout=4,encoding="utf-8",errors="replace",creationflags=flags)
            if state.returncode!=0 or state.stdout.strip().lower()!="device":
                raise RuntimeError("ADB не подтверждает состояние 'device'. Разблокируйте шлем, подтвердите USB debugging и повторите подключение.")
            try:
                help_result=subprocess.run([self.scrcpy_path,"--help"],capture_output=True,text=True,timeout=5,
                    encoding="utf-8",errors="replace",creationflags=flags)
                help_text=(help_result.stdout or "")+"\n"+(help_result.stderr or "")
            except Exception as exc:
                LOGGER.warning("Не удалось определить возможности scrcpy: %s",exc); help_text=""
            source_size=None
            try:
                size_result=subprocess.run([self.adb_path,"-s",self.serial,"shell","wm","size"],capture_output=True,text=True,
                    timeout=2,encoding="utf-8",errors="replace",creationflags=flags)
                if size_result.returncode==0:
                    source_size=parse_android_size(size_result.stdout+"\n"+size_result.stderr)
            except Exception:
                LOGGER.debug("Размер Android-дисплея не получен; запуск без авто-кадрирования",exc_info=True)
            crop=None
            if source_size:
                rect=crop_rectangle(source_size,self.eye,self.calibration)
                if rect:
                    cw,ch,cx,cy=rect; crop=f"{cw}:{ch}:{cx}:{cy}"
            elif self.eye=="Левый" or any(
                int(self.calibration.get(k, DEFAULT_CALIBRATION[k])) != DEFAULT_CALIBRATION[k]
                for k in ("x", "y", "width", "height")
            ):
                LOGGER.warning("Размер дисплея не определён; авто-кадрирование отключено для этого запуска")
            args=build_scrcpy_args(
                self.scrcpy_path,self.serial,self.resolution,self.fps,self.bitrate,self.title,
                help_text,crop,rotation=int(self.calibration.get("rotation", 0)),video_encoder=self.video_encoder,
            )
            self.completed.emit({"args":args,"title":self.title,"source_size":source_size,"crop":crop},"")
        except Exception as exc:
            self.completed.emit(None,f"{type(exc).__name__}: {exc}")


class VideoEncoderListWorker(QThread):
    """Query video encoder names without blocking the application UI."""
    completed = Signal(bool, object, str)

    def __init__(self, scrcpy_path, serial, parent=None):
        super().__init__(parent)
        self.scrcpy_path = scrcpy_path
        self.serial = str(serial)

    def run(self):
        try:
            result = subprocess.run(
                [self.scrcpy_path, "--serial", self.serial, "--list-encoders"],
                capture_output=True, text=True, timeout=12, encoding="utf-8", errors="replace",
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
            )
            output = (result.stdout or "") + "\n" + (result.stderr or "")
            encoders = parse_scrcpy_video_encoders(output, "h264")
            if encoders:
                self.completed.emit(True, encoders, "")
                return
            detail = "\n".join(
                line for line in output.splitlines()
                if "encoder" in line.lower() or "error" in line.lower()
            )
            if not detail:
                detail = output.strip()[-1600:] or "scrcpy не вернул список кодеров."
            self.completed.emit(False, [], detail)
        except subprocess.TimeoutExpired:
            self.completed.emit(False, [], "Шлем не ответил на запрос списка кодеров за 12 секунд. Проверьте соединение и повторите попытку.")
        except Exception as exc:
            LOGGER.exception("Не удалось получить список H.264-кодеров")
            self.completed.emit(False, [], f"{type(exc).__name__}: {exc}")


def find_native_window(title_fragment: str, expected_pid: int | None = None) -> int | None:
    """Find a visible Win32 top-level window by title and, optionally, process ID."""
    if os.name != "nt" or not title_fragment:
        return None
    try:
        from ctypes import wintypes
        user32=ctypes.WinDLL("user32",use_last_error=True)
        user32.IsWindowVisible.argtypes=[wintypes.HWND]; user32.IsWindowVisible.restype=wintypes.BOOL
        user32.GetWindowTextLengthW.argtypes=[wintypes.HWND]; user32.GetWindowTextLengthW.restype=ctypes.c_int
        user32.GetWindowTextW.argtypes=[wintypes.HWND,wintypes.LPWSTR,ctypes.c_int]; user32.GetWindowTextW.restype=ctypes.c_int
        user32.GetWindowThreadProcessId.argtypes=[wintypes.HWND,ctypes.POINTER(wintypes.DWORD)]
        user32.GetWindowThreadProcessId.restype=wintypes.DWORD
        found=[]
        EnumWindowsProc=ctypes.WINFUNCTYPE(wintypes.BOOL,wintypes.HWND,wintypes.LPARAM)
        def callback(hwnd, _):
            try:
                if not user32.IsWindowVisible(hwnd): return True
                length=user32.GetWindowTextLengthW(hwnd)
                if length<=0: return True
                buffer=ctypes.create_unicode_buffer(length+1)
                user32.GetWindowTextW(hwnd,buffer,length+1)
                if title_fragment.casefold() not in buffer.value.casefold(): return True
                if expected_pid is not None:
                    pid=wintypes.DWORD(0)
                    user32.GetWindowThreadProcessId(hwnd,ctypes.byref(pid))
                    if int(pid.value)!=int(expected_pid): return True
                found.append(int(hwnd)); return False
            except Exception:
                LOGGER.debug("Не удалось проверить Win32-окно",exc_info=True)
                return True
        user32.EnumWindows.argtypes=[EnumWindowsProc,wintypes.LPARAM]
        user32.EnumWindows.restype=wintypes.BOOL
        user32.EnumWindows(EnumWindowsProc(callback),0)
        return found[0] if found else None
    except Exception:
        LOGGER.exception("Ошибка поиска окна scrcpy через Win32 API")
        return None

def stamp(): return datetime.now().strftime("%Y-%m-%d %H:%M:%S")
def log_event(level, message):
    level = str(level).upper()
    # Avoid persisting private LAN addresses in ordinary event logs.
    message = redact_ips(str(message))
    line=f"[{stamp()}] [{level}] {message}"
    numeric = {"DEBUG": logging.DEBUG, "INFO": logging.INFO, "WARN": logging.WARNING,
               "WARNING": logging.WARNING, "ERROR": logging.ERROR, "CRITICAL": logging.CRITICAL}.get(level, logging.INFO)
    LOGGER.log(numeric, message)
    try:
        daily=LOG_DIR / ("events-"+datetime.now().strftime("%Y-%m-%d")+".log")
        with daily.open("a", encoding="utf-8") as f:
            f.write(line+"\n")
        # latest-log.txt is deliberately maintained separately for the UI log viewer.
        latest=LOG_DIR/"latest-log.txt"
        with latest.open("a", encoding="utf-8") as f:
            f.write(line+"\n")
        if latest.stat().st_size>1_000_000:
            lines=latest.read_text(encoding="utf-8",errors="replace").splitlines()[-3000:]
            latest.write_text("\n".join(lines)+"\n",encoding="utf-8")
    except Exception:
        LOGGER.exception("Не удалось записать журнал событий")
    try:
        BUS.log.emit(level, line)
    except Exception:
        LOGGER.exception("Не удалось передать событие в интерфейс")
def save_config():
    """Atomically persist settings so an interrupted write cannot corrupt JSON."""
    temp_path = CONFIG_PATH.with_suffix(CONFIG_PATH.suffix + ".tmp")
    try:
        CONFIG_DIR.mkdir(parents=True, exist_ok=True)
        payload = json.dumps(CFG, ensure_ascii=False, indent=2)
        with temp_path.open("w", encoding="utf-8", newline="\n") as handle:
            handle.write(payload)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temp_path, CONFIG_PATH)
        LOGGER.debug("Настройки сохранены")
        return True
    except Exception:
        LOGGER.exception("Не удалось сохранить настройки в %s", CONFIG_PATH)
        try: temp_path.unlink(missing_ok=True)
        except Exception: pass
        return False

def _uncaught_exception(exc_type, exc_value, exc_tb):
    if issubclass(exc_type, KeyboardInterrupt):
        sys.__excepthook__(exc_type, exc_value, exc_tb)
        return
    LOGGER.critical("Необработанное исключение", exc_info=(exc_type, exc_value, exc_tb))
sys.excepthook = _uncaught_exception

STYLE = """
QMainWindow, QWidget { background:#080c14; color:#e8eef8; font-family:'Segoe UI'; font-size:13px; }
QFrame#panel, QGroupBox { background:#0d1421; border:1px solid #1c2939; border-radius:10px; }
QGroupBox { margin-top:12px; padding:12px; font-weight:600; }
QGroupBox::title { subcontrol-origin:margin; left:12px; padding:0 6px; color:#94a0b8; }
QLabel#muted { color:#8492aa; } QLabel#title { font-size:22px; font-weight:650; }
QLabel#brand { color:#94a0b8; letter-spacing:2px; font-weight:600; }
QPushButton { background:#172235; color:#dce7f6; border:1px solid #293a51; border-radius:7px; padding:9px 13px; }
QPushButton:hover { background:#20324a; border-color:#22d3ee; }
QPushButton#primary { background:#0e3540; border:1px solid #1c7888; color:#b7f5ff; font-weight:600; }
QPushButton#danger { background:#391b26; border-color:#713348; color:#ffb5c4; }
QLineEdit, QComboBox, QSpinBox { background:#080e18; border:1px solid #27364b; border-radius:6px; padding:8px; color:#e8eef8; }
QComboBox QAbstractItemView { background:#0d1421; selection-background-color:#174451; }
QTabWidget::pane { border:1px solid #1c2939; border-radius:8px; background:#0a101b; }
QTabBar::tab { background:#0c1320; color:#8e9bb0; padding:12px 14px; margin-right:3px; border-top-left-radius:6px; border-top-right-radius:6px; }
QTabBar::tab:selected { color:#5ce6f7; background:#122330; border-bottom:2px solid #22d3ee; }
QTextEdit, QListWidget { background:#060a11; border:1px solid #1c2939; border-radius:7px; color:#a7b6cb; }
QSlider::groove:horizontal { height:4px; background:#243246; border-radius:2px; }
QSlider::handle:horizontal { background:#22d3ee; width:13px; margin:-5px 0; border-radius:6px; }
QCheckBox { spacing:8px; color:#bdc9da; }
QCheckBox::indicator { width:15px; height:15px; }
QCheckBox::indicator:checked { background:#22d3ee; border:1px solid #22d3ee; border-radius:3px; }
QProgressBar { background:#101a29; border:0; border-radius:3px; height:5px; text-align:center; }
QProgressBar::chunk { background:#22d3ee; border-radius:3px; }
"""
def panel():
    f=QFrame(); f.setObjectName("panel"); return f
def heading(text):
    l=QLabel(text); l.setObjectName("title"); return l
def muted(text):
    l=QLabel(text); l.setObjectName("muted"); return l

class App(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("SPECTRA — VR Operator Console")
        self.resize(1420,900); self.setMinimumSize(1050,700)
        self.connected=False; self.streaming=False; self.device=""; self.device_name=""; self.device_state=""
        self.devices=[]; self.scrcpy_proc=None; self.scrcpy_reader=None; self.scrcpy_log_handle=None
        self.current_tab=0; self.video_hwnd=None; self.video_qwindow=None; self.video_container=None
        self._calibration_device=""; self._resume_stream_after_reconnect=False
        self.stream_title=""; self._embed_attempts=0; self.current_fps=None
        self.scan_worker=None; self.metrics_worker=None; self.stream_prep_worker=None
        self.tools_worker=None; self.wifi_worker=None; self._scan_select_first=False
        self.installing_tools=False; self._last_auto_reconnect_attempt=0.0; self._closing_requested=False; self._close_retry_scheduled=False
        self.connect_output_widget=None; self.wifi_connect_button=None
        self.keep_awake_originals=dict(CFG.get("keep_awake_originals", {})); self.keep_awake_applied=set()
        self._last_external_capture_warning=0.0
        self.adb_path=resolve_binary("adb")
        self.central=QWidget(); self.setCentralWidget(self.central)
        root=QVBoxLayout(self.central); root.setContentsMargins(18,14,18,12); root.setSpacing(12)
        top=QHBoxLayout()
        brand=QLabel("●  S P E C T R A"); brand.setObjectName("brand"); top.addWidget(brand)
        top.addWidget(muted("VR OPERATOR CONSOLE"))
        top.addStretch()
        self.status=QLabel("●  НЕ ПОДКЛЮЧЕНО"); self.status.setStyleSheet("color:#9aa8bd;font-weight:700;")
        top.addWidget(self.status)
        connect=QPushButton("Подключить шлем"); connect.setObjectName("primary"); connect.clicked.connect(self.show_connect); top.addWidget(connect)
        info=QPushButton("Информация"); info.clicked.connect(lambda:self.tabs.setCurrentIndex(6)); top.addWidget(info)
        root.addLayout(top)
        self.tabs=QTabWidget(); root.addWidget(self.tabs,1)
        self.tabs.addTab(self.make_stream_tab(),"◉  Трансляция")
        self.tabs.addTab(self.make_external_tab(),"▣  Внешний экран")
        self.tabs.addTab(self.make_metrics_tab(),"⌁  Метрики")
        self.tabs.addTab(self.make_calibration_tab(),"◎  Калибровка")
        self.tabs.addTab(self.make_settings_tab(),"⚙  Настройки")
        self.tabs.addTab(self.make_logs_tab(),"≡  Журнал")
        self.tabs.addTab(self.make_info_tab(),"ⓘ  Информация")
        bottom=QHBoxLayout()
        self.bottom_status=QLabel(f"Шлемов: 0  ·  Режим: —  ·  v{APP_VERSION}  ·  RU"); self.bottom_status.setObjectName("muted")
        bottom.addWidget(self.bottom_status); bottom.addStretch()
        self.log_toggle=QPushButton("⌄  Последние события"); self.log_toggle.clicked.connect(self.toggle_console); bottom.addWidget(self.log_toggle)
        root.addLayout(bottom)
        self.console=QTextEdit(); self.console.setReadOnly(True); self.console.setMaximumHeight(110); self.console.document().setMaximumBlockCount(500); self.console.hide(); root.addWidget(self.console)
        BUS.log.connect(self.on_log)
        self.timer=QTimer(self); self.timer.timeout.connect(self.refresh_state); self.timer.start(800)
        self.scan_timer=QTimer(self); self.scan_timer.timeout.connect(self.start_device_scan); self.scan_timer.start(4000)
        self.metrics_timer=QTimer(self); self.metrics_timer.timeout.connect(self.start_metrics_scan); self.metrics_timer.start(2500)
        self.embed_timer=QTimer(self); self.embed_timer.setInterval(200); self.embed_timer.timeout.connect(self._poll_scrcpy_window)
        QShortcut(QKeySequence("Ctrl+M"),self,activated=self.toggle_compact)
        log_event("INFO","SPECTRA запущена")
        self.refresh_state(); self.start_device_scan()
        if CFG.get("first_run",True): QTimer.singleShot(300,self.show_welcome)

    def make_stream_tab(self):
        w=QWidget(); layout=QHBoxLayout(w); layout.setContentsMargins(12,14,12,12); layout.setSpacing(14)
        left=QVBoxLayout(); layout.addLayout(left,4)
        title=QHBoxLayout(); title.addWidget(heading("Трансляция")); title.addStretch()
        self.live_badge=QLabel("● ОЖИДАНИЕ")
        self.live_badge.setStyleSheet("color:#94a3b8;font-weight:700;")
        title.addWidget(self.live_badge); left.addLayout(title)
        self.video=QFrame(); self.video.setMinimumHeight(380); self.video.setStyleSheet("background:#03060a;border:1px solid #1d2a3b;border-radius:10px;")
        self.video_layout=QVBoxLayout(self.video); self.video_layout.setContentsMargins(8,8,8,8); self.video_layout.setSpacing(5)
        self.osd_bar=QLabel(""); self.osd_bar.setWordWrap(True)
        self.osd_bar.setStyleSheet("color:#86a0b8;background:#080e18;border:1px solid #1c2939;border-radius:5px;padding:5px 8px;font-size:11px;")
        self.video_layout.addWidget(self.osd_bar)
        self.video_surface=QFrame(); self.video_surface.setObjectName("videoSurface")
        self.video_surface.setAttribute(Qt.WA_NativeWindow, True)
        self.video_surface.setStyleSheet("background:#03060a;border:0;")
        self.video_surface_layout=QVBoxLayout(self.video_surface); self.video_surface_layout.setContentsMargins(0,0,0,0); self.video_surface_layout.setSpacing(0)
        self.video_msg=QLabel("ОЖИДАНИЕ ВИДЕОПОТОКА\n\nПодключите Meta Quest 3 через USB или Wi-Fi")
        self.video_msg.setAlignment(Qt.AlignCenter); self.video_msg.setWordWrap(True)
        self.video_msg.setStyleSheet("color:#5d718a;font-size:17px;background:#03060a;")
        self.video_surface_layout.addWidget(self.video_msg,1)
        self.video_layout.addWidget(self.video_surface,1)
        left.addWidget(self.video,1)
        controls=QHBoxLayout()
        self.stream_btn=QPushButton("▶  Начать трансляцию"); self.stream_btn.setObjectName("primary"); self.stream_btn.clicked.connect(self.toggle_stream); controls.addWidget(self.stream_btn)
        b=QPushButton("↻ Переподключить"); b.clicked.connect(self.reconnect); controls.addWidget(b)
        b=QPushButton("⛶ Полный экран"); b.clicked.connect(self.toggle_fullscreen); controls.addWidget(b)
        b=QPushButton("OSD"); b.clicked.connect(self.osd_dialog); controls.addWidget(b)
        self.eye_button=QPushButton("◐ Глаз: "+CFG["eye"]); self.eye_button.clicked.connect(self.switch_eye); controls.addWidget(self.eye_button)
        b=QPushButton("▧ Снимок"); b.clicked.connect(self.screenshot); controls.addWidget(b)
        left.addLayout(controls)
        right=QVBoxLayout(); layout.addLayout(right,1)
        p=panel(); pl=QVBoxLayout(p); pl.setContentsMargins(14,14,14,14)
        row=QHBoxLayout(); row.addWidget(QLabel("Подключённые устройства")); row.addStretch()
        self.headset_count=QLabel("0 найдено"); self.headset_count.setStyleSheet("color:#22d3ee"); row.addWidget(self.headset_count); pl.addLayout(row)
        self.headset_list=QListWidget(); self.headset_list.setMaximumHeight(230); self.headset_list.itemClicked.connect(self.select_headset); pl.addWidget(self.headset_list)
        rowbuttons=QHBoxLayout()
        add=QPushButton("+ Подключить"); add.clicked.connect(self.show_connect); rowbuttons.addWidget(add)
        scan=QPushButton("Обновить"); scan.clicked.connect(self.start_device_scan); rowbuttons.addWidget(scan)
        pl.addLayout(rowbuttons)
        self.disconnect_btn=QPushButton("Отключить Wi-Fi / снять USB-выбор"); self.disconnect_btn.clicked.connect(self.disconnect_device); pl.addWidget(self.disconnect_btn)
        self.tools_status=muted("Проверка ADB и scrcpy…"); self.tools_status.setWordWrap(True); pl.addWidget(self.tools_status)
        self.install_tools_button=QPushButton("Установить / обновить ADB + scrcpy из ZIP"); self.install_tools_button.clicked.connect(self.install_tools); pl.addWidget(self.install_tools_button)
        pl.addSpacing(8); pl.addWidget(QLabel("СЕССИЯ"))
        self.side_mode=muted("Режим: не подключено"); pl.addWidget(self.side_mode)
        self.side_resolution=muted(f"Разрешение: {CFG['resolution']} · {CFG['fps']} FPS"); pl.addWidget(self.side_resolution)
        self.side_latency=muted("ADB round-trip: —"); pl.addWidget(self.side_latency)
        self.side_ip=muted("Устройство: —"); pl.addWidget(self.side_ip)
        self.side_battery=muted("Заряд: —"); pl.addWidget(self.side_battery)
        pl.addStretch()
        note=QLabel("Видео декодируется scrcpy и в Windows встраивается прямо в эту панель. Если версия scrcpy или драйвер окна не позволит встраивание, журнал укажет причину.")
        note.setWordWrap(True); note.setObjectName("muted"); pl.addWidget(note)
        right.addWidget(p,1)
        self.update_osd()
        return w

    def make_external_tab(self):
        w=QWidget(); l=QVBoxLayout(w); l.setContentsMargins(18,18,18,18)
        l.addWidget(heading("Внешний экран")); l.addWidget(muted("Зеркало встроенного видеопотока на выбранный дисплей. Превью обновляется примерно 5 раз/с."))
        p=panel(); g=QGridLayout(p); g.setContentsMargins(18,18,18,18)
        self.external_check=QCheckBox("Включить зеркало на внешний экран"); self.external_check.toggled.connect(lambda _checked: self.apply_external()); g.addWidget(self.external_check,0,0,1,2)
        g.addWidget(QLabel("Дисплей"),1,0); self.display_combo=QComboBox()
        self.refresh_screens()
        g.addWidget(self.display_combo,1,1)
        refresh_screens_btn=QPushButton("Обновить дисплеи"); refresh_screens_btn.clicked.connect(self.refresh_screens); g.addWidget(refresh_screens_btn,1,2)
        g.addWidget(QLabel("Масштабирование"),2,0); self.fit_combo=QComboBox(); self.fit_combo.addItems(["Fit","Fill","Stretch"]); self.fit_combo.setCurrentText(CFG["external_fit"]); g.addWidget(self.fit_combo,2,1)
        g.addWidget(muted("Для зеркала нужен запущенный поток. Закройте окно зеркала, сняв флажок."),3,0,1,2)
        btn=QPushButton("Применить настройки"); btn.setObjectName("primary"); btn.clicked.connect(self.apply_external); g.addWidget(btn,4,1)
        l.addWidget(p); l.addStretch()
        self.external_window=None; self.external_label=None
        self.external_timer=QTimer(self); self.external_timer.setInterval(180); self.external_timer.timeout.connect(self.update_external_preview)
        return w

    def make_metrics_tab(self):
        w=QWidget(); l=QVBoxLayout(w); l.setContentsMargins(18,18,18,18); l.addWidget(heading("Метрики и состояние устройства"))
        grid=QGridLayout(); self.metric_labels={}; self.metric_notes={}
        metric_defs=[("latency","ADB round-trip","мс", "Измерение команды adb get-state, не задержка видеокадра"),
                     ("fps","FPS потока","FPS", "Только если установленная версия scrcpy печатает FPS"),
                     ("bitrate","Битрейт","Мбит/с", "Запрошенное значение из настроек; фактическое не выдаётся scrcpy"),
                     ("drops","Потеря кадров","—", "Недоступно без статистики декодера/сети")]
        for i,(key,title,unit,note_text) in enumerate(metric_defs):
            p=panel(); v=QVBoxLayout(p); v.setContentsMargins(18,18,18,18); v.addWidget(muted(title))
            value=QLabel("—"); value.setStyleSheet("font-size:30px;font-weight:700;color:#22d3ee;"); v.addWidget(value)
            note=muted(note_text); note.setWordWrap(True); v.addWidget(note)
            self.metric_labels[key]=value; self.metric_notes[key]=note; grid.addWidget(p,i//2,i%2)
        l.addLayout(grid)
        health=QGroupBox("Состояние системы"); form=QFormLayout(health)
        self.health_conn=QLabel("Нет подключения"); self.health_headset=QLabel("Не определён"); self.health_battery=QLabel("Недоступно"); self.health_model=QLabel("—")
        form.addRow("Соединение",self.health_conn); form.addRow("Модель",self.health_headset); form.addRow("Заряд",self.health_battery); form.addRow("Источник ADB",self.health_model)
        l.addWidget(health)
        l.addWidget(muted("SPECTRA не подставляет случайные значения: там, где scrcpy/ADB не предоставляет достоверные данные, отображается тире."))
        l.addStretch(); return w

    def make_calibration_tab(self):
        w=QWidget(); l=QVBoxLayout(w); l.setContentsMargins(18,18,18,18); l.addWidget(heading("Кадрирование трансляции"))
        note=muted("Нулевое положение ползунков соответствует стандартной калибровке: X −16, Y 0, ширина 77%, высота 40%. Ползунки задают поправку к этим значениям. Поворот настраивается в градусах и применяется при запуске трансляции; доступный диапазон зависит от версии scrcpy.")
        note.setWordWrap(True); l.addWidget(note)
        p=panel(); v=QVBoxLayout(p); v.setContentsMargins(20,20,20,20); self.cal_sliders={}; self.calibration_value_labels={}
        controls = [
            ("x", "Смещение X (база −16)", CFG["calibration"]["x"]),
            ("y", "Смещение Y (база 0)", CFG["calibration"]["y"]),
            ("width", "Ширина кадра (Δ%, база 77%)", CFG["calibration"]["width"]),
            ("height", "Высота кадра (Δ%, база 40%)", CFG["calibration"]["height"]),
            ("rotation", "Поворот (°)", CFG["calibration"]["rotation"]),
        ]
        for key,label,val in controls:
            mn,mx=calibration_adjustment_limits(key)
            adjustment=calibration_adjustment(key,val)
            row=QHBoxLayout(); row.addWidget(QLabel(label),1)
            slider=QSlider(Qt.Horizontal); slider.setRange(mn,mx); slider.setValue(adjustment)
            value=QLabel(self._format_calibration_adjustment(key,adjustment)); value.setMinimumWidth(48)
            slider.valueChanged.connect(
                lambda n,k=key,lab=value: (
                    lab.setText(self._format_calibration_adjustment(k,n)),
                    CFG["calibration"].update({k:calibration_from_adjustment(k,n)}),
                )
            )
            row.addWidget(slider,4); row.addWidget(value); v.addLayout(row)
            self.cal_sliders[key]=slider; self.calibration_value_labels[key]=value
        buttons=QHBoxLayout(); save=QPushButton("Сохранить пресет"); save.setObjectName("primary"); save.clicked.connect(self.save_calibration); buttons.addWidget(save)
        reset=QPushButton("Сбросить к стандарту"); reset.clicked.connect(self.reset_calibration); buttons.addWidget(reset); v.addLayout(buttons); l.addWidget(p); l.addStretch(); return w

    @staticmethod
    def _format_calibration_adjustment(key, value):
        value=int(value)
        if key == "rotation":
            return f"{value}°"
        if key in {"width", "height"}:
            return f"{value:+d}%" if value else "0%"
        return f"{value:+d}" if value else "0"

    def make_settings_tab(self):
        w=QWidget(); l=QVBoxLayout(w); l.setContentsMargins(18,18,18,18); l.addWidget(heading("Настройки"))
        stream=QGroupBox("Трансляция"); g=QGridLayout(stream)
        g.addWidget(QLabel("Глаз"),0,0); self.eye_combo=QComboBox(); self.eye_combo.addItems(["Правый","Левый"]); self.eye_combo.setCurrentText(CFG["eye"]); g.addWidget(self.eye_combo,0,1)
        g.addWidget(QLabel("Разрешение"),0,2); self.res_combo=QComboBox(); self.res_combo.addItems(["720p","1080p","1440p"]); self.res_combo.setCurrentText(CFG["resolution"]); g.addWidget(self.res_combo,0,3)
        g.addWidget(QLabel("FPS"),1,0); self.fps_combo=QComboBox(); self.fps_combo.addItems(["24","30","60"]); self.fps_combo.setCurrentText(CFG["fps"]); g.addWidget(self.fps_combo,1,1)
        g.addWidget(QLabel("Битрейт (Мбит/с)"),1,2); self.bitrate_spin=QSpinBox(); self.bitrate_spin.setRange(5,40); self.bitrate_spin.setValue(CFG["bitrate"]); g.addWidget(self.bitrate_spin,1,3)
        self.auto_bitrate=QCheckBox("Авто-битрейт (недоступен в текущей версии)"); self.auto_bitrate.setChecked(False); self.auto_bitrate.setEnabled(False); self.auto_bitrate.setToolTip("SPECTRA не получает достоверную телеметрию канала для безопасной автоматической регулировки."); g.addWidget(self.auto_bitrate,2,0,1,4)
        g.addWidget(QLabel("Видеокодер H.264"),3,0)
        self.video_encoder_combo=QComboBox(); self.video_encoder_combo.addItem("Автоматически (выбор scrcpy)", "")
        saved_encoder=str(CFG.get("video_encoder", "") or "").strip()
        if saved_encoder: self.video_encoder_combo.addItem(saved_encoder, saved_encoder)
        self.video_encoder_combo.setCurrentIndex(max(0,self.video_encoder_combo.findData(saved_encoder)))
        self.video_encoder_combo.setToolTip("Если поток падает с ошибкой MediaCodec, выберите другой кодер из списка, полученного от шлема.")
        g.addWidget(self.video_encoder_combo,3,1,1,2)
        self.encoder_refresh_btn=QPushButton("Найти кодеры"); self.encoder_refresh_btn.clicked.connect(self.refresh_video_encoders); g.addWidget(self.encoder_refresh_btn,3,3)
        encoder_note=muted("При ошибках MediaCodec попробуйте другой доступный H.264-кодер. Список запрашивается с подключённого шлема; по умолчанию выбор остаётся за scrcpy.")
        encoder_note.setWordWrap(True); g.addWidget(encoder_note,4,0,1,4)
        behavior=QGroupBox("Поведение"); bg=QVBoxLayout(behavior)
        self.keep_awake=QCheckBox("Не давать шлему засыпать (только текущая сессия)"); self.keep_awake.setChecked(CFG["keep_awake"]); bg.addWidget(self.keep_awake)
        self.auto_reconnect=QCheckBox("Автопереподключение при обрыве"); self.auto_reconnect.setChecked(CFG["auto_reconnect"]); bg.addWidget(self.auto_reconnect)
        system=QGroupBox("Система"); sg=QGridLayout(system)
        sg.addWidget(QLabel("Язык"),0,0); self.lang_combo=QComboBox(); self.lang_combo.addItems(["Русский (RU) — единственный реализованный язык"]); self.lang_combo.setEnabled(False); sg.addWidget(self.lang_combo,0,1)
        openlogs=QPushButton("Открыть папку логов"); openlogs.clicked.connect(self.open_logs); sg.addWidget(openlogs,0,2)
        reset=QPushButton("Сбросить настройки"); reset.clicked.connect(self.reset_settings); sg.addWidget(reset,0,3)
        save=QPushButton("Сохранить настройки"); save.setObjectName("primary"); save.clicked.connect(self.save_settings); sg.addWidget(save,1,3)
        l.addWidget(stream); l.addWidget(behavior); l.addWidget(system); l.addStretch(); return w

    def make_logs_tab(self):
        w=QWidget(); l=QVBoxLayout(w); l.setContentsMargins(18,18,18,18)
        top=QHBoxLayout(); top.addWidget(heading("Журнал событий")); top.addStretch()
        self.log_filter=QComboBox(); self.log_filter.addItems(["Всё","Info","Warning","Error"]); self.log_filter.currentTextChanged.connect(self.refresh_logs); top.addWidget(self.log_filter)
        b=QPushButton("Открыть папку"); b.clicked.connect(self.open_logs); top.addWidget(b)
        export=QPushButton("Экспорт логов…"); export.clicked.connect(self.export_diagnostics); top.addWidget(export)
        l.addLayout(top)
        self.log_view=QTextEdit(); self.log_view.setReadOnly(True); l.addWidget(self.log_view,1); self.refresh_logs(); return w

    def make_info_tab(self):
        w=QWidget(); l=QVBoxLayout(w); l.setContentsMargins(18,18,18,18); l.addWidget(heading("О программе"))
        p=panel(); v=QVBoxLayout(p); v.setContentsMargins(22,22,22,22)
        for text in ["SPECTRA — VR Operator Console",f"Версия: {APP_VERSION} (encoder diagnostics and selection update)","Техникум: КГАМТ им. Л.Б. Васильева","Разработчики: thwere x feralyth1337","Назначение: локальная трансляция изображения с Meta Quest 3","Компоненты: Python · PySide6 · ADB · scrcpy","Приватность: приложение не выполняет внешние сетевые запросы; инструменты устанавливаются из выбранного локального ZIP-архива"]:
            lab=QLabel(text); lab.setWordWrap(True); v.addWidget(lab)
        b=QPushButton("Скопировать отчёт"); b.clicked.connect(self.copy_report); v.addWidget(b)
        readme=QPushButton("Открыть README"); readme.clicked.connect(lambda:self.open_path(APP_DIR/"README.txt")); v.addWidget(readme)
        l.addWidget(p); l.addStretch(); return w

    def show_welcome(self):
        dlg=QDialog(self); dlg.setWindowTitle("Добро пожаловать в SPECTRA"); dlg.resize(540,340)
        v=QVBoxLayout(dlg); v.addWidget(heading("Добро пожаловать в SPECTRA"))
        v.addWidget(muted("Передавайте изображение с Meta Quest 3 на ноутбук оператора по локальному USB или Wi‑Fi."))
        b=QPushButton("Подключить по кабелю"); b.setObjectName("primary"); b.clicked.connect(lambda:(dlg.accept(),self.show_connect())); v.addWidget(b)
        b=QPushButton("Уже настроено — по Wi‑Fi"); b.clicked.connect(lambda:(dlg.accept(),self.show_connect())); v.addWidget(b)
        b=QPushButton("Знаю IP-адрес"); b.clicked.connect(lambda:(dlg.accept(),self.show_connect(manual=True))); v.addWidget(b)
        dlg.exec(); CFG["first_run"]=False; save_config()

    def show_connect(self, manual=False):
        dlg=QDialog(self); dlg.setWindowTitle("Подключение шлема"); dlg.resize(590,440)
        v=QVBoxLayout(dlg); v.addWidget(heading("Подключение Meta Quest 3"))
        v.addWidget(muted("USB: подключите кабель и подтвердите USB debugging в шлеме."))
        v.addWidget(muted("Wi-Fi: сначала подключите шлем по USB. Оставьте IP пустым для автоопределения или введите его вручную."))
        form=QFormLayout(); ip=QLineEdit(CFG.get("last_ip","")); ip.setPlaceholderText("пусто = авто по USB, например 192.168.1.42")
        ip_row=QHBoxLayout(); ip_row.addWidget(ip,1); ip_auto=QPushButton("Авто IP"); ip_auto.setToolTip("Очистить сохранённый адрес и определить IP шлема через USB")
        ip_auto.clicked.connect(lambda:ip.clear()); ip_row.addWidget(ip_auto)
        ip_widget=QWidget(); ip_widget.setLayout(ip_row); form.addRow("IP шлема",ip_widget); v.addLayout(form)
        out=QTextEdit(); out.setReadOnly(True); out.setMaximumHeight(130); v.addWidget(out)
        row=QHBoxLayout(); usb=QPushButton("Найти по USB"); usb.setObjectName("primary")
        wifi=QPushButton("Подключить по Wi-Fi"); wifi.setObjectName("primary")
        row.addWidget(usb); row.addWidget(wifi); v.addLayout(row)
        cancel=QPushButton("Закрыть"); cancel.clicked.connect(dlg.reject); v.addWidget(cancel)
        self.connect_output_widget=out
        if manual: ip.setFocus()
        def run_usb():
            out.append("Сканирую устройства ADB в фоне…")
            self._scan_select_first=True
            self.start_device_scan(force=True)
        def run_wifi():
            addr=ip.text().strip()
            if addr and not valid_ipv4(addr):
                out.append("Введите корректный IPv4-адрес либо оставьте поле пустым для автоопределения по USB.")
                return
            if not self.adb_path:
                out.append("ADB не найден. Нажмите «Установить / обновить ADB + scrcpy из ZIP» в панели устройств.")
                return
            current=getattr(self,"wifi_worker",None)
            if current is not None and current.isRunning():
                out.append("Подключение уже выполняется…")
                return
            usb_serial=""
            if self.connected and self.device and ":" not in self.device:
                usb_serial=self.device
            else:
                usb_device=next((d for d in self.devices if d.get("state")=="device" and ":" not in d.get("serial","")),None)
                if usb_device: usb_serial=usb_device.get("serial","")
            if not addr and not usb_serial:
                out.append("Введите IP-адрес или сначала подключите шлем по USB, чтобы SPECTRA определила IP автоматически.")
                return
            wifi_worker=WifiConnectWorker(self.adb_path,addr,usb_serial,self)
            wifi_worker.progress.connect(self._on_wifi_progress)
            wifi_worker.completed.connect(self._on_wifi_completed)
            wifi_worker.finished.connect(lambda w=wifi_worker:self._finish_wifi_worker(w))
            self.wifi_worker=wifi_worker; self.wifi_connect_button=wifi
            wifi.setEnabled(False); out.append("Подключение запущено в фоне; окно можно оставить открытым.")
            wifi_worker.start()
        usb.clicked.connect(run_usb); wifi.clicked.connect(run_wifi)
        dlg.finished.connect(lambda *_: setattr(self,"connect_output_widget",None))
        dlg.exec()

    def _on_wifi_progress(self, message):
        widget=getattr(self,"connect_output_widget",None)
        if widget is not None:
            widget.append(str(message))

    def _on_wifi_completed(self, success, message, address):
        if self._closing_requested:
            return
        widget=getattr(self,"connect_output_widget",None)
        if widget is not None:
            widget.append(str(message))
        if success:
            CFG["last_ip"]=address; save_config()
            log_event("INFO","ADB-подключение по Wi-Fi подтверждено командой connect; проверяю состояние устройства")
            self._scan_select_first=False
            self.start_device_scan(force=True)
        else:
            log_event("WARN","Не удалось подключить устройство по Wi-Fi; проверьте локальную сеть и TCP/IP ADB")
            if widget is not None:
                widget.append("Подключение не подтверждено. Для нового Android Wireless Debugging могут потребоваться сопряжение и отдельный порт, а не 5555.")

    def _finish_wifi_worker(self, worker):
        if getattr(self,"wifi_worker",None) is worker:
            self.wifi_worker=None
        button=getattr(self,"wifi_connect_button",None)
        if button is not None:
            try:
                button.setEnabled(True)
            except RuntimeError:
                # The modal connection dialog may have been closed while ADB was working.
                pass
        self.wifi_connect_button=None
        worker.deleteLater()

    def adb(self,args):
        adb=self.adb_path or resolve_binary("adb")
        if not adb:
            log_event("ERROR","ADB не найден; команда не выполнена")
            return "ADB не найден. Поместите adb.exe и DLL в папку adb/ рядом с приложением."
        command=[adb]+list(args)
        safe_command=list(command)
        for i, value in enumerate(safe_command[:-1]):
            if value == "-s":
                safe_command[i+1] = "<DEVICE>"
        LOGGER.debug("ADB command: %s", safe_command)
        try:
            r=subprocess.run(command,capture_output=True,text=True,timeout=6,
                creationflags=getattr(subprocess,"CREATE_NO_WINDOW",0),encoding="utf-8",errors="replace")
            output=(r.stdout+"\n"+r.stderr).strip()
            if r.returncode == 0:
                LOGGER.debug("ADB команда завершена успешно; операция=%s", args[0] if args else "unknown")
            else:
                safe_output=output
                for i, value in enumerate(args[:-1]):
                    if value == "-s" and args[i+1]:
                        safe_output=safe_output.replace(str(args[i+1]),"<DEVICE>")
                LOGGER.warning("ADB завершился с кодом %s; операция=%s; вывод=%s", r.returncode, args[0] if args else "unknown", safe_output[-2000:])
            if r.returncode != 0:
                return (output + "\n" if output else "") + f"[ADB_EXIT_CODE={r.returncode}]"
            return output or "Команда выполнена (код 0)."
        except subprocess.TimeoutExpired:
            LOGGER.warning("Превышено время ожидания команды ADB; операция=%s", args[0] if args else "unknown")
            return "ADB не ответил за 6 секунд. Проверьте подключение устройства и повторите попытку."
        except Exception as e:
            LOGGER.exception("Ошибка выполнения ADB; операция=%s", args[0] if args else "unknown")
            log_event("ERROR",f"ADB: {type(e).__name__}")
            return str(e)

    def start_device_scan(self, force=False):
        """Scan ADB asynchronously. Never run two competing scans at once."""
        if getattr(self,"installing_tools",False) or getattr(self,"_closing_requested",False):
            return
        if getattr(self,"scan_worker",None) is not None and self.scan_worker.isRunning():
            return
        self.adb_path=resolve_binary("adb")
        if not self.adb_path:
            if hasattr(self,"headset_list"):
                self.headset_list.clear()
                item=QListWidgetItem("ADB НЕ НАЙДЕН\nПоложите adb.exe в папку adb/")
                item.setFlags(item.flags() & ~Qt.ItemIsEnabled & ~Qt.ItemIsSelectable)
                self.headset_list.addItem(item)
            if not getattr(self,"_adb_missing_logged",False):
                log_event("ERROR","ADB не найден: ожидается adb/adb.exe или adb в PATH")
                self._adb_missing_logged=True
            if hasattr(self,"health_model"): self.health_model.setText("ADB не найден")
            return
        self._adb_missing_logged=False
        auto_ip=CFG.get("last_ip","") if CFG.get("auto_reconnect",True) else ""
        do_auto=bool(auto_ip and CFG.get("auto_reconnect",True) and time.monotonic()-self._last_auto_reconnect_attempt>=15)
        if do_auto: self._last_auto_reconnect_attempt=time.monotonic()
        worker=DeviceScanWorker(self.adb_path,auto_ip,do_auto,self)
        worker.completed.connect(self._on_scan_completed)
        worker.finished.connect(lambda w=worker: self._finish_scan_worker(w))
        self.scan_worker=worker
        worker.start()
        if force: log_event("INFO","Запущено сканирование устройств ADB")

    def _finish_scan_worker(self, worker):
        if self.scan_worker is worker:
            self.scan_worker=None
        worker.deleteLater()

    def _on_scan_completed(self, devices, error, elapsed):
        if error:
            LOGGER.warning("ADB scan failed: %s", error)
            widget=getattr(self,"connect_output_widget",None)
            if widget is not None:
                widget.append("Ошибка сканирования ADB: "+str(error))
            # A failed/timeout scan is not evidence that the device disconnected.
            self.refresh_state()
            return
        old_connected=self.connected
        self.devices=list(devices or [])
        # Recover a prior session's keep-awake setting after a crash or forced shutdown.
        # Only run for currently authorized devices and don't undo this live session's setting.
        for recovered in self.devices:
            recovered_serial = recovered.get("serial", "")
            if recovered.get("state") == "device" and recovered_serial in self.keep_awake_originals and recovered_serial not in self.keep_awake_applied:
                self._restore_keep_awake(recovered_serial)
        ready=[d for d in self.devices if d.get("state")=="device"]
        # If a saved Wi-Fi target reconnects, select it automatically rather than
        # leaving the status stuck at "disconnected" while ADB already sees it.
        if not self.device and CFG.get("auto_reconnect") and CFG.get("last_ip"):
            saved_serial=str(CFG["last_ip"]).strip()+":5555"
            saved_device=next((d for d in ready if d.get("serial")==saved_serial),None)
            if saved_device:
                self.device=saved_device["serial"]
                self.device_name=saved_device.get("model","Android device")
                self.device_state="device"
                self.connected=True
                log_event("INFO","Восстановлено устройство из сохранённого адреса ADB")
        if self._scan_select_first:
            self._scan_select_first=False
            if ready:
                chosen=ready[0]
                self.device=chosen["serial"]; self.device_name=chosen.get("model","Android device")
                self.device_state="device"; self.connected=True
                CFG["last_ip"]="" if ":" not in self.device else CFG.get("last_ip","")
                save_config(); log_event("INFO","Выбрано первое авторизованное устройство ADB")
                widget=getattr(self,"connect_output_widget",None)
                if widget is not None:
                    widget.append("Подключено: "+self.device_name+" (серийный номер скрыт в обычных логах).")
            else:
                widget=getattr(self,"connect_output_widget",None)
                if widget is not None:
                    widget.append("Авторизованных устройств нет. Проверьте запрос USB debugging в шлеме.")
        current=next((d for d in self.devices if d.get("serial")==self.device),None) if self.device else None
        if current:
            self.device_state=current.get("state","")
            self.device_name=current.get("model","Android device")
            self.connected=self.device_state=="device"
        elif self.device:
            self.connected=False
            self.device_state="не найден"
        else:
            self.connected=False; self.device_state=""
        if self.connected and self.device and self._calibration_device != self.device:
            self._activate_device_calibration(self.device)
        if self.streaming and not self.connected:
            self._resume_stream_after_reconnect = bool(CFG.get("auto_reconnect", True))
            log_event("WARN","Устройство потеряно во время трансляции; остановка scrcpy")
            # Keep the operator's external mirror open during a transient disconnect
            # only when automatic recovery is enabled.
            self.stop_stream(show_message=False, preserve_external=self._resume_stream_after_reconnect)
        if self.connected and not old_connected and self._resume_stream_after_reconnect:
            QTimer.singleShot(900, self._resume_stream_if_ready)
        if old_connected and not self.connected and self.device:
            self._restore_keep_awake(self.device)
        elif self.connected and not old_connected and CFG.get("keep_awake"):
            self._apply_keep_awake()
        self._update_device_list()
        self.refresh_state()
        if self.connected:
            self.start_metrics_scan()
        LOGGER.debug("ADB scan completed: devices=%d, ready=%d, duration=%.0fms",len(self.devices),len(ready),elapsed*1000)

    def _activate_device_calibration(self, serial):
        """Persist the outgoing calibration and load a distinct profile per device."""
        serial=str(serial or "").strip()
        if not serial:
            return
        profiles=CFG.setdefault("calibration_profiles", {})
        old_serial=getattr(self,"_calibration_device","")
        if old_serial and old_serial != serial:
            profiles[old_serial]=normalize_calibration(CFG.get("calibration",{}))
        if serial in profiles:
            active=normalize_calibration(profiles.get(serial))
        elif not profiles:
            # Migrate a legacy installation's global calibration to its first device.
            active=normalize_calibration(CFG.get("calibration",{}))
            profiles[serial]=copy.deepcopy(active)
        else:
            active=normalize_calibration(DEFAULTS["calibration"])
            profiles[serial]=copy.deepcopy(active)
        CFG["calibration"]=active
        self._calibration_device=serial
        for key, slider in getattr(self,"cal_sliders",{}).items():
            if key not in active:
                continue
            slider.blockSignals(True)
            adjustment=calibration_adjustment(key, active[key])
            slider.setValue(adjustment)
            slider.blockSignals(False)
            label=getattr(self,"calibration_value_labels",{}).get(key)
            if label is not None:
                label.setText(self._format_calibration_adjustment(key, adjustment))
        save_config()
        log_event("INFO","Загружен профиль кадрирования выбранного устройства")

    def _resume_stream_if_ready(self):
        if not self._resume_stream_after_reconnect or self._closing_requested:
            return
        if not CFG.get("auto_reconnect", True):
            self._resume_stream_after_reconnect=False
            return
        if not self.connected or not self.device:
            return  # Keep the intent; a later ADB scan will try again.
        if self.streaming or (self.scrcpy_proc is not None and self.scrcpy_proc.poll() is None):
            self._resume_stream_after_reconnect=False
            return
        self._resume_stream_after_reconnect=False
        log_event("INFO","Устройство восстановлено; автоматический перезапуск трансляции")
        self.toggle_stream()

    def _update_device_list(self):
        if not hasattr(self,"headset_list"): return
        old=self.headset_list.currentItem().data(Qt.UserRole) if self.headset_list.currentItem() else self.device
        self.headset_list.blockSignals(True); self.headset_list.clear()
        for d in self.devices:
            serial=d.get("serial",""); state=d.get("state", "unknown"); model=d.get("model", "Android device")
            status={"device":"ГОТОВО","unauthorized":"РАЗРЕШИТЕ USB DEBUGGING","offline":"ОФЛАЙН"}.get(state,state.upper())
            item=QListWidgetItem(f"●  {model}\n    {serial}\n    {status}")
            item.setData(Qt.UserRole,serial); item.setData(Qt.UserRole+1,state); item.setData(Qt.UserRole+2,model)
            self.headset_list.addItem(item)
            if serial==old: self.headset_list.setCurrentItem(item)
        if not self.devices and self.adb_path:
            item=QListWidgetItem("Устройства не найдены\nПодключите USB или настройте ADB по Wi-Fi")
            item.setFlags(item.flags() & ~Qt.ItemIsEnabled & ~Qt.ItemIsSelectable)
            self.headset_list.addItem(item)
        self.headset_count.setText(f"{len(self.devices)} найдено")
        self.headset_list.blockSignals(False)

    def start_metrics_scan(self):
        if getattr(self,"installing_tools",False) or getattr(self,"_closing_requested",False):
            return
        if not self.connected or not self.device or not self.adb_path:
            return
        if getattr(self,"metrics_worker",None) is not None and self.metrics_worker.isRunning():
            return
        worker=MetricsWorker(self.adb_path,self.device,self)
        worker.completed.connect(self._on_metrics_completed)
        worker.finished.connect(lambda w=worker: self._finish_metrics_worker(w))
        self.metrics_worker=worker; worker.start()

    def _finish_metrics_worker(self, worker):
        if self.metrics_worker is worker: self.metrics_worker=None
        worker.deleteLater()

    def _on_metrics_completed(self, serial, values, error):
        if serial!=self.device: return
        if error:
            LOGGER.debug("Метрики устройства недоступны: %s",error)
            self.side_latency.setText("ADB round-trip: —")
            self.side_battery.setText("Заряд: Недоступно")
            self.health_battery.setText("Недоступно")
            self.metric_labels["latency"].setText("—")
            self.metric_labels["drops"].setText("—")
            # A transient ADB metrics error must not erase independent FPS reported by scrcpy.
            if not self.streaming or self.current_fps is None:
                self.metric_labels["fps"].setText("—")
            return
        latency=values.get("latency_ms")
        self.side_latency.setText(f"ADB round-trip: {latency:.0f} мс" if latency is not None else "ADB round-trip: —")
        bat=values.get("battery",{})
        level=bat.get("level")
        temp=bat.get("temperature_c")
        parts=[]
        if level is not None: parts.append(f"{level}%")
        if temp is not None: parts.append(f"{temp:.1f} °C")
        if bat.get("plugged"): parts.append(str(bat["plugged"]))
        battery_text=" · ".join(parts) if parts else "Недоступно"
        self.side_battery.setText("Заряд: "+battery_text)
        self.health_battery.setText(battery_text)
        self.metric_labels["latency"].setText(f"{latency:.0f}" if latency is not None else "—")
        self.metric_labels["bitrate"].setText(str(CFG.get("bitrate",16)))
        if self.current_fps is not None and self.streaming:
            self.metric_labels["fps"].setText(f"{self.current_fps:.1f}")
        else:
            self.metric_labels["fps"].setText("—")
        self.metric_labels["drops"].setText("—")
        self.health_conn.setText("Подключено · "+("Wi-Fi" if ":" in serial else "USB"))
        self.health_headset.setText(self.device_name or "Android device")
        self.health_model.setText(self.adb_path or "ADB не найден")

    def disconnect_device(self):
        if not self.device:
            QMessageBox.information(self,"Нет выбранного устройства","Сначала выберите устройство в списке.")
            return
        serial=self.device
        self._resume_stream_after_reconnect=False  # Explicit disconnect cancels automatic stream resume.
        if self.streaming: self.stop_stream(show_message=False)
        self._restore_keep_awake(serial)
        if ":" in serial:
            result=self.adb(["disconnect",serial])
            ip=serial.rsplit(":",1)[0]
            if CFG.get("last_ip")==ip:
                CFG["last_ip"]=""  # An explicit disconnect must not be undone by auto-reconnect.
                save_config()
            log_event("INFO","Отключено Wi-Fi-подключение ADB; сохранённый адрес автоподключения очищен при совпадении")
            QMessageBox.information(self,"Отключение",result)
        else:
            CFG["last_ip"]=""
            save_config()
            QMessageBox.information(self,"USB-устройство","ADB не может программно отключить физический USB-кабель. Выбор снят; для полного отключения извлеките кабель.")
            log_event("INFO","Снят выбор USB-устройства без отключения физического кабеля")
        self.device=""; self.device_name=""; self.device_state=""; self.connected=False
        self.refresh_state(); self.start_device_scan(force=True)

    def _update_tools_status(self):
        if not hasattr(self,"tools_status"): return
        adb=resolve_binary("adb"); scrcpy=resolve_binary("scrcpy")
        if adb and scrcpy:
            text="Инструменты готовы · ADB и scrcpy найдены"
        elif adb:
            text="ADB найден · scrcpy отсутствует — установите ZIP ниже"
        elif scrcpy:
            text="scrcpy найден · ADB отсутствует — установите ZIP ниже"
        else:
            text="ADB / scrcpy не найдены · выберите официальный ZIP ниже"
        if self.tools_status.text()!=text: self.tools_status.setText(text)

    def install_tools(self):
        if self.streaming or (self.scrcpy_proc is not None and self.scrcpy_proc.poll() is None):
            QMessageBox.information(self,"Сначала остановите трансляцию","Перед обновлением ADB/scrcpy остановите текущую трансляцию. Это позволит безопасно заменить исполняемые файлы и DLL.")
            return
        worker=getattr(self,"tools_worker",None)
        if worker is not None and worker.isRunning():
            QMessageBox.information(self,"Установка инструментов","Установка уже выполняется."); return
        QMessageBox.information(self,"Подготовка инструментов",
            "SPECTRA не скачивает файлы из интернета.\n\n1. Откройте страницу официальных релизов scrcpy в браузере:\nhttps://github.com/Genymobile/scrcpy/releases/latest\n\n2. Скачайте архив Windows x64 с именем вида scrcpy-win64-vX.Y.Z.zip.\n3. В следующем окне выберите этот ZIP.\n\nПрограмма проверит структуру архива и установит инструменты локально.")
        archive_name,_=QFileDialog.getOpenFileName(self,"Выберите официальный архив scrcpy для Windows x64",str(APP_DIR),
            "scrcpy Windows x64 (*.zip);;Все файлы (*.*)")
        if not archive_name:
            return
        if not re.fullmatch(r"scrcpy-win64-v[^/\\]+\.zip",Path(archive_name).name,re.I):
            QMessageBox.warning(self,"Неверный архив","Выберите официальный файл вида scrcpy-win64-vX.Y.Z.zip из релиза Windows x64.")
            return
        answer=QMessageBox.question(self,"Установить инструменты",
            f"Установить локальный архив {Path(archive_name).name} в папку scrcpy/?\n\nТекущая папка scrcpy/ будет заменена после проверки архива. Продолжить?",
            QMessageBox.Yes|QMessageBox.No,QMessageBox.No)
        if answer!=QMessageBox.Yes: return
        self.installing_tools=True
        self.scan_timer.stop(); self.metrics_timer.stop()
        self.install_tools_button.setEnabled(False)
        self.tools_status.setText("Проверяю выбранный ZIP…")
        worker=ToolsInstallWorker(APP_DIR,Path(archive_name),self)
        worker.progress.connect(self._on_tools_install_progress)
        worker.completed.connect(self._on_tools_install_completed)
        worker.finished.connect(lambda w=worker:self._finish_tools_worker(w))
        self.tools_worker=worker; worker.start()

    def _on_tools_install_progress(self, message):
        if hasattr(self,"tools_status"): self.tools_status.setText(message)

    def _finish_tools_worker(self, worker):
        if getattr(self,"tools_worker",None) is worker: self.tools_worker=None
        self.installing_tools=False
        if hasattr(self,"install_tools_button"): self.install_tools_button.setEnabled(True)
        worker.deleteLater()
        if not self._closing_requested:
            self.scan_timer.start(4000); self.metrics_timer.start(2500)
            self.adb_path=resolve_binary("adb")
            self._update_tools_status(); self.start_device_scan(force=True)

    def _on_tools_install_completed(self, success, message):
        if success:
            self.adb_path=resolve_binary("adb")
            log_event("INFO","Официальные инструменты ADB/scrcpy установлены или обновлены")
            self._update_tools_status()
            if not self._closing_requested:
                QMessageBox.information(self,"Инструменты установлены",message)
        else:
            log_event("ERROR","Не удалось установить ADB/scrcpy; подробности в журнале")
            if hasattr(self,"tools_status"): self.tools_status.setText("Установка не удалась · см. logs/spectra.log")
            if not self._closing_requested:
                QMessageBox.critical(self,"Ошибка установки",message+"\n\nТакже можно установить scrcpy вручную: https://github.com/Genymobile/scrcpy/releases/latest")

    def update_osd(self):
        if not hasattr(self,"osd_bar"): return
        options=CFG.get("osd",{})
        tokens=[]
        if options.get("live",True): tokens.append("● LIVE" if self.streaming else "○ STANDBY")
        if options.get("mode",True): tokens.append(f"{CFG.get('resolution','1080p')} · {CFG.get('fps','30')} FPS · {CFG.get('bitrate',16)} Mbps")
        if options.get("eye",True): tokens.append(f"Глаз: {CFG.get('eye','Правый')} · {self.device_name or 'шлем не выбран'}")
        if options.get("metrics",True):
            lat=self.metric_labels.get("latency") if hasattr(self,"metric_labels") else None
            tokens.append("ADB: "+(lat.text()+" мс" if lat and lat.text()!="—" else "—"))
        if options.get("clock",True): tokens.append(datetime.now().strftime("%H:%M:%S"))
        self.osd_bar.setText("     ·     ".join(tokens))
        self.osd_bar.setAlignment((Qt.AlignRight if "Правый" in options.get("position","Правый верх") else Qt.AlignLeft) | Qt.AlignVCenter)
        self.osd_bar.setVisible(bool(tokens))
        position=options.get("position","Правый верх")
        if getattr(self,"_osd_position",None)!=position:
            self.video_layout.removeWidget(self.osd_bar)
            if "низ" in position.lower(): self.video_layout.addWidget(self.osd_bar)
            else: self.video_layout.insertWidget(0,self.osd_bar)
            self._osd_position=position

    def _restore_keep_awake(self, serial=None):
        targets=[serial] if serial else list(getattr(self,"keep_awake_originals",{}))
        for target in targets:
            if not target or target not in self.keep_awake_originals:
                continue
            original=str(self.keep_awake_originals[target])
            result=self.adb(["-s",target,"shell","settings","put","system","stay_on_while_plugged_in",original])
            if "[ADB_EXIT_CODE=" in result or "error:" in result.lower():
                LOGGER.warning("Не удалось восстановить исходный keep-awake для выбранного устройства: %s",result[-500:])
                log_event("WARN","Не удалось восстановить исходную настройку keep-awake; повторная попытка при доступности устройства")
                continue
            self.keep_awake_originals.pop(target,None)
            self.keep_awake_applied.discard(target)
            CFG["keep_awake_originals"] = dict(self.keep_awake_originals)
            save_config()
            log_event("INFO","Исходная настройка keep-awake восстановлена")

    def _apply_keep_awake(self):
        # Do not leave the previous selected device permanently awake after switching.
        if not CFG.get("keep_awake"):
            self._restore_keep_awake()
            return
        for old_serial in list(self.keep_awake_applied):
            if old_serial != self.device:
                self._restore_keep_awake(old_serial)
        if not self.device or not self.connected:
            return
        serial=self.device
        if serial in self.keep_awake_applied:
            return
        if serial not in self.keep_awake_originals:
            old=self.adb(["-s",serial,"shell","settings","get","system","stay_on_while_plugged_in"]).strip()
            if not re.fullmatch(r"\d+",old):
                LOGGER.warning("Не удалось определить исходную настройку stay_on_while_plugged_in: %s",old[-500:])
                log_event("WARN","Не удалось безопасно включить keep-awake: исходное значение настройки не удалось определить")
                return
            self.keep_awake_originals[serial]=old
            CFG["keep_awake_originals"] = dict(self.keep_awake_originals)
            save_config()  # Record rollback data before changing the device setting.
        result=self.adb(["-s",serial,"shell","settings","put","system","stay_on_while_plugged_in","3"])
        if "[ADB_EXIT_CODE=" in result or "error:" in result.lower():
            LOGGER.warning("Не удалось применить keep-awake: %s",result[-500:])
            log_event("WARN","Не удалось применить keep-awake; см. logs/spectra.log")
            return
        self.keep_awake_applied.add(serial)
        log_event("INFO","Экран шлема удерживается активным на время сессии")

    def _poll_scrcpy_window(self):
        if not self.scrcpy_proc or self.scrcpy_proc.poll() is not None:
            self.embed_timer.stop(); return
        self._embed_attempts+=1
        hwnd=find_native_window(self.stream_title,self.scrcpy_proc.pid)
        if hwnd is None and self._embed_attempts>=10:
            # Some scrcpy builds create the SDL window on a helper PID. The title is unique per session.
            hwnd=find_native_window(self.stream_title,None)
        if hwnd:
            try:
                foreign=QWindow.fromWinId(hwnd)
                if foreign is None:
                    raise RuntimeError("Qt не смог обернуть HWND окна scrcpy")
                container=QWidget.createWindowContainer(foreign,self.video_surface)
                if container is None:
                    raise RuntimeError("Qt не создал контейнер для окна scrcpy")
                container.setMinimumSize(160,120); container.setFocusPolicy(Qt.StrongFocus)
                container.setStyleSheet("background:#03060a;border:0;")
                self.video_surface_layout.addWidget(container,1)
                self.video_container=container; self.video_qwindow=foreign; self.video_hwnd=int(hwnd)
                self.video_msg.hide(); container.show()
                self.embed_timer.stop()
                self.live_badge.setText("● LIVE · ВСТРОЕНО")
                log_event("INFO","Окно scrcpy встроено в главный экран SPECTRA")
                self.update_osd()
                return
            except Exception:
                LOGGER.exception("Не удалось встроить окно scrcpy")
                self._detach_video_container()
                self.video_msg.setText("Не удалось встроить окно scrcpy. Поток остановлен, чтобы не оставлять отдельное окно.\n\nПроверьте logs/spectra.log и logs/scrcpy.log.")
                self.stop_stream(show_message=False, event_level="ERROR", event_message="Встраивание окна scrcpy завершилось ошибкой; поток остановлен")
                self.video_msg.setText("Не удалось встроить окно scrcpy. Поток остановлен, чтобы не оставлять отдельное окно.\n\nПроверьте logs/spectra.log и logs/scrcpy.log.")
                return
        if self._embed_attempts>=50:
            self.embed_timer.stop()
            self.video_msg.setText("Окно scrcpy не найдено за 10 секунд. Поток остановлен, чтобы не оставлять отдельное окно.\n\nПроверьте logs/scrcpy.log.")
            self.stop_stream(show_message=False, event_level="ERROR", event_message="Окно scrcpy не найдено за 10 секунд; поток остановлен")
            self.video_msg.setText("Окно scrcpy не найдено за 10 секунд. Поток остановлен, чтобы не оставлять отдельное окно.\n\nПроверьте logs/scrcpy.log.")

    def _detach_video_container(self):
        container=getattr(self,"video_container",None)
        if container is not None:
            try:
                self.video_surface_layout.removeWidget(container)
                container.hide(); container.setParent(None); container.deleteLater()
            except Exception: LOGGER.exception("Не удалось удалить embedded video container")
        self.video_container=None; self.video_qwindow=None; self.video_hwnd=None
        if hasattr(self,"video_msg"): self.video_msg.show()

    def on_scrcpy_output(self, line):
        safe=redact_ips(str(line))
        LOGGER.debug("scrcpy: %s",safe)
        value=parse_scrcpy_fps(safe)
        if value is not None:
            self.current_fps=value
            if hasattr(self,"metric_labels"): self.metric_labels["fps"].setText(f"{value:.1f}")
            self.update_osd()

    def toggle_stream(self):
        if self._closing_requested:
            return
        if self.streaming:
            self.stop_stream(); return
        if getattr(self,"stream_prep_worker",None) is not None and self.stream_prep_worker.isRunning():
            return
        if not self.connected or not self.device:
            QMessageBox.information(self,"Нет подключения","Сначала подключите и выберите авторизованное устройство ADB.")
            self.show_connect(); return
        scrcpy=resolve_binary("scrcpy"); adb=resolve_binary("adb")
        if not adb:
            QMessageBox.warning(self,"ADB не найден","Нажмите «Установить / обновить ADB + scrcpy из ZIP» в панели устройств.")
            return
        if not scrcpy:
            QMessageBox.warning(self,"scrcpy не найден","Нажмите «Установить / обновить ADB + scrcpy из ZIP» в панели устройств.")
            return
        self.stream_btn.setEnabled(False)
        self.live_badge.setText("● ПОДГОТОВКА"); self.live_badge.setStyleSheet("color:#eab308;font-weight:700;")
        self.video_msg.setText("Проверяю подключение и параметры scrcpy…\n\nЭто может занять несколько секунд."); self.video_msg.show()
        worker=StreamPrepWorker(adb,scrcpy,self.device,CFG["resolution"],CFG["fps"],CFG["bitrate"],CFG["eye"],CFG.get("calibration",{}),video_encoder=CFG.get("video_encoder", ""),parent=self)
        worker.completed.connect(self._on_stream_prepared)
        worker.finished.connect(lambda w=worker: self._finish_stream_prep_worker(w))
        self.stream_prep_worker=worker; worker.start()

    def _finish_stream_prep_worker(self, worker):
        if self.stream_prep_worker is worker: self.stream_prep_worker=None
        # The button is needed to stop a successfully started stream too.
        self.stream_btn.setEnabled(True)
        worker.deleteLater()

    def _on_stream_prepared(self, payload, error):
        if self._closing_requested:
            self.streaming=False
            self.stream_btn.setEnabled(True); self.stream_btn.setText("▶  Начать трансляцию")
            self.live_badge.setText("● ОЖИДАНИЕ")
            return
        if error or not payload:
            self.stream_btn.setEnabled(True)
            self.live_badge.setText("● ОЖИДАНИЕ"); self.live_badge.setStyleSheet("color:#94a3b8;font-weight:700;")
            self.video_msg.setText("Не удалось подготовить трансляцию.\n\nПроверьте подключение, scrcpy и logs/spectra.log.")
            LOGGER.error("Подготовка потока завершилась ошибкой: %s",error)
            QMessageBox.warning(self,"Не удалось подготовить поток",str(error))
            self.start_device_scan(force=True); return
        args=payload["args"]; title=payload["title"]; self.stream_title=title
        try:
            safe_args=list(args[1:])
            if "--serial" in safe_args:
                serial_index=safe_args.index("--serial")+1
                if serial_index < len(safe_args): safe_args[serial_index]="<DEVICE>"
            LOGGER.info("Запуск scrcpy: %s",["<SCRCPY>",*safe_args])
            self.current_fps=None; self._embed_attempts=0
            self.video_msg.setText("Подключаюсь к устройству…\n\nОжидаю окно видеопотока и встраиваю его в SPECTRA.")
            self.video_msg.show()
            self.scrcpy_proc=subprocess.Popen(args,cwd=str(Path(args[0]).resolve().parent),stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,text=True,encoding="utf-8",errors="replace",bufsize=1,
                creationflags=getattr(subprocess,"CREATE_NO_WINDOW",0))
            self.scrcpy_reader=ScrcpyOutputReader(self.scrcpy_proc,LOG_DIR/"scrcpy.log",title,self)
            self.scrcpy_reader.line_received.connect(self.on_scrcpy_output); self.scrcpy_reader.start()
            self.streaming=True
            self.stream_btn.setText("Ⅱ  Остановить трансляцию")
            self.live_badge.setText("● LIVE · ПОДКЛЮЧЕНИЕ"); self.live_badge.setStyleSheet("color:#eab308;font-weight:700;")
            self.embed_timer.start(); self._apply_keep_awake(); self.update_osd(); self.refresh_state()
            if payload.get("crop"): log_event("INFO","Кадрирование применено при запуске scrcpy")
            elif CFG.get("eye")=="Левый" or any(
                int(CFG.get("calibration",{}).get(k,DEFAULT_CALIBRATION[k])) != DEFAULT_CALIBRATION[k]
                for k in ("x", "y", "width", "height")
            ):
                log_event("WARN","Кадрирование пропущено: источник не удалось уверенно определить или он не side-by-side")
            log_event("INFO","Трансляция запускается; ожидается встраивание окна scrcpy")
        except Exception as exc:
            LOGGER.exception("Не удалось запустить scrcpy")
            self._cleanup_stream_process(); self.streaming=False
            self.stream_btn.setEnabled(True); self.stream_btn.setText("▶  Начать трансляцию")
            self.live_badge.setText("● ОЖИДАНИЕ")
            QMessageBox.critical(self,"Ошибка запуска",f"Не удалось запустить scrcpy. Подробности: logs/spectra.log\n\n{exc}")
            log_event("ERROR","Не удалось запустить scrcpy: "+str(exc))

    def _cleanup_stream_process(self):
        self.embed_timer.stop()
        proc=getattr(self,"scrcpy_proc",None)
        if proc is not None and proc.poll() is None:
            try:
                proc.terminate(); proc.wait(timeout=3)
            except subprocess.TimeoutExpired:
                try: proc.kill(); proc.wait(timeout=2)
                except Exception: LOGGER.exception("Не удалось принудительно остановить scrcpy")
            except Exception: LOGGER.exception("Ошибка завершения scrcpy")
        reader=getattr(self,"scrcpy_reader",None)
        if reader is not None and reader.isRunning():
            reader.wait(2000)
        try:
            if proc is not None and proc.stdout is not None: proc.stdout.close()
        except Exception: pass
        self.scrcpy_reader=None; self.scrcpy_proc=None
        self._detach_video_container()

    def stop_stream(self, show_message=True, refresh=True, event_level="INFO", event_message="Трансляция остановлена", preserve_external=False):
        self.embed_timer.stop()
        proc=getattr(self,"scrcpy_proc",None)
        if proc is not None and proc.poll() is None:
            try:
                proc.terminate(); proc.wait(timeout=3)
            except subprocess.TimeoutExpired:
                LOGGER.warning("scrcpy не завершился вовремя; принудительное завершение")
                try: proc.kill(); proc.wait(timeout=2)
                except Exception: LOGGER.exception("Не удалось завершить процесс scrcpy")
            except Exception: LOGGER.exception("Ошибка остановки scrcpy")
        reader=getattr(self,"scrcpy_reader",None)
        if reader is not None and reader.isRunning(): reader.wait(2000)
        try:
            if proc is not None and proc.stdout is not None: proc.stdout.close()
        except Exception: pass
        self.scrcpy_reader=None; self.scrcpy_proc=None
        self._detach_video_container()
        self.streaming=False; self.current_fps=None
        self.metric_labels["fps"].setText("—")
        self.stream_btn.setText("▶  Начать трансляцию")
        self.live_badge.setText("● ОЖИДАНИЕ"); self.live_badge.setStyleSheet("color:#94a3b8;font-weight:700;")
        if show_message:
            self.video_msg.setText("ТРАНСЛЯЦИЯ ОСТАНОВЛЕНА\n\nНажмите «Начать трансляцию», чтобы возобновить.")
        if self.external_window is not None and not preserve_external:
            self.external_timer.stop()
            if hasattr(self,"external_check"):
                self.external_check.blockSignals(True); self.external_check.setChecked(False); self.external_check.blockSignals(False)
            self.external_window.close(); self.external_window=None; self.external_label=None
        log_event(event_level,event_message); self.update_osd()
        if refresh: self.refresh_state()

    def reconnect(self):
        log_event("INFO","Запрошено переподключение")
        if not self.device:
            self.show_connect(); return
        if ":" in self.device:
            result=self.adb(["connect",self.device])
            QMessageBox.information(self,"Переподключение",result)
        else:
            result=self.adb(["-s",self.device,"get-state"])
            if result.strip().lower()!="device":
                self.connected=False
                QMessageBox.warning(self,"Переподключение","Устройство недоступно. Проверьте кабель и подтвердите USB debugging.")
            else:
                QMessageBox.information(self,"Переподключение","ADB подтверждает подключение устройства.")
        self.start_device_scan(force=True); self.refresh_state()

    def switch_eye(self):
        CFG["eye"]="Левый" if CFG["eye"]=="Правый" else "Правый"; save_config()
        self.eye_button.setText("◐ Глаз: "+CFG["eye"])
        self.eye_combo.setCurrentText(CFG["eye"])
        log_event("INFO","Выбран глаз: "+CFG["eye"])
        if self.streaming:
            self.stop_stream(show_message=False,event_message="Перезапуск потока для применения кадрирования",preserve_external=True)
            QTimer.singleShot(500,self.toggle_stream)
        self.update_osd(); self.refresh_state()

    def screenshot(self):
        if not self.connected or not self.device:
            QMessageBox.information(self,"Нет подключения","Сначала подключите шлем."); return
        adb=resolve_binary("adb")
        if not adb:
            QMessageBox.warning(self,"ADB не найден","Положите adb.exe и DLL в папку adb рядом с приложением."); return
        target=APP_DIR/("snapshot_"+datetime.now().strftime("%Y%m%d-%H%M%S")+".png")
        try:
            p=subprocess.run([adb,"-s",self.device,"exec-out","screencap","-p"],capture_output=True,timeout=10,
                creationflags=getattr(subprocess,"CREATE_NO_WINDOW",0))
            dimensions=parse_png_dimensions(p.stdout)
            if p.returncode==0 and dimensions:
                target.write_bytes(p.stdout)
                QMessageBox.information(self,"Снимок сохранён",f"Файл: {target}\nРазмер: {dimensions[0]}×{dimensions[1]}")
                log_event("INFO","Снимок экрана устройства сохранён")
            else:
                LOGGER.error("Не удалось получить PNG-кадр; код ADB=%s; stdout_head=%r; stderr=%r",p.returncode,p.stdout[:32],p.stderr[:500])
                QMessageBox.warning(self,"Снимок недоступен","ADB не вернул корректный PNG. Подробности — logs/spectra.log.")
                log_event("ERROR","Не удалось сделать снимок через ADB")
        except Exception as e:
            LOGGER.exception("Ошибка создания снимка")
            QMessageBox.warning(self,"Ошибка снимка",str(e)); log_event("ERROR",f"Ошибка снимка: {type(e).__name__}")

    def toggle_fullscreen(self):
        if self.isFullScreen(): self.showNormal()
        else: self.showFullScreen()
    def toggle_compact(self):
        if self.width()<500:
            self.setWindowFlag(Qt.WindowStaysOnTopHint,False); self.showNormal(); self.resize(1420,900)
        else:
            self.resize(420,270); self.setWindowFlag(Qt.WindowStaysOnTopHint,True); self.show()
    def osd_dialog(self):
        dlg=QDialog(self); dlg.setWindowTitle("Настройки OSD"); v=QVBoxLayout(dlg)
        checks={}
        for key,label in [("live","LIVE-бейдж"),("mode","Режим / разрешение / FPS"),("metrics","Метрики"),("eye","Глаз и имя шлема"),("clock","Время")]:
            cb=QCheckBox(label); cb.setChecked(CFG["osd"].get(key,True)); checks[key]=cb; v.addWidget(cb)
        combo=QComboBox(); combo.addItems(["Левый верх","Правый верх","Левый низ","Правый низ"]); combo.setCurrentText(CFG["osd"].get("position","Правый верх")); v.addWidget(combo)
        b=QPushButton("Сохранить"); b.setObjectName("primary")
        def save():
            for k,cb in checks.items(): CFG["osd"][k]=cb.isChecked()
            CFG["osd"]["position"]=combo.currentText(); save_config(); self.update_osd()
            log_event("INFO","Настройки OSD сохранены"); dlg.accept()
        b.clicked.connect(save); v.addWidget(b); dlg.exec()

    def refresh_screens(self):
        if not hasattr(self,"display_combo"):
            return
        selected=self.display_combo.currentData()
        self.display_combo.blockSignals(True)
        self.display_combo.clear()
        for i,screen in enumerate(QApplication.screens()):
            geom=screen.geometry()
            self.display_combo.addItem(f"{i+1}. {screen.name()} ({geom.width()}×{geom.height()})",i)
        idx=self.display_combo.findData(selected) if selected is not None else -1
        if idx>=0: self.display_combo.setCurrentIndex(idx)
        self.display_combo.blockSignals(False)
        if self.display_combo.count()==0:
            self.display_combo.addItem("Дисплеи не обнаружены",0)

    def apply_external(self):
        CFG["external_fit"]=self.fit_combo.currentText(); save_config()
        if not self.external_check.isChecked():
            self.external_timer.stop()
            if self.external_window is not None: self.external_window.close()
            self.external_window=None; self.external_label=None
            log_event("INFO","Зеркало внешнего экрана выключено"); return
        screens=QApplication.screens()
        if not screens:
            QMessageBox.warning(self,"Внешний экран","Windows не сообщает доступных дисплеев."); return
        index=self.display_combo.currentData()
        try: index=int(index)
        except (TypeError,ValueError): index=0
        index=max(0,min(index,len(screens)-1))
        if self.external_window is not None:
            self.external_window.close()
        self.external_window=QWidget(None,Qt.Window)
        self.external_window.setWindowTitle("SPECTRA — Mirror")
        self.external_window.setStyleSheet("background:#000000;color:#9ca3af;")
        layout=QVBoxLayout(self.external_window); layout.setContentsMargins(0,0,0,0)
        self.external_label=QLabel("Ожидание встроенного видеопотока")
        self.external_label.setAlignment(Qt.AlignCenter); self.external_label.setStyleSheet("background:#000000;color:#9ca3af;")
        layout.addWidget(self.external_label)
        screen=screens[index]
        self.external_window.setGeometry(screen.geometry()); self.external_window.showFullScreen()
        self.external_timer.start(); self.update_external_preview()
        log_event("INFO",f"Зеркало включено на дисплее {index+1}; режим {CFG['external_fit']}")

    def update_external_preview(self):
        if self.external_window is None or self.external_label is None or not self.external_check.isChecked():
            self.external_timer.stop(); return
        if not self.streaming or not self.video_hwnd:
            self.external_label.setText("Ожидание видео внутри SPECTRA")
            self.external_label.setPixmap(QPixmap())
            return
        try:
            screens=QApplication.screens()
            screen_index=self.display_combo.currentData()
            try: screen_index=int(screen_index)
            except (TypeError,ValueError): screen_index=0
            pixmap=None
            # The source HWND belongs to the operator window, not necessarily to the
            # selected output monitor. Try each source screen before reporting a blank frame.
            for source_screen in screens:
                candidate=source_screen.grabWindow(int(self.video_hwnd))
                if candidate is not None and not candidate.isNull():
                    pixmap=candidate
                    break
            if pixmap is None or pixmap.isNull():
                if time.monotonic()-self._last_external_capture_warning>5:
                    self._last_external_capture_warning=time.monotonic()
                    LOGGER.warning("Снимок встроенного окна для внешнего зеркала пуст; возможны ограничения драйвера Windows")
                self.external_label.setText("Не удалось захватить окно видеопотока")
                return
            size=self.external_label.size()
            mode=CFG.get("external_fit","Fit")
            if mode=="Stretch":
                scaled=pixmap.scaled(size,Qt.IgnoreAspectRatio,Qt.SmoothTransformation)
            elif mode=="Fill":
                scaled=pixmap.scaled(size,Qt.KeepAspectRatioByExpanding,Qt.SmoothTransformation)
                x=max(0,(scaled.width()-size.width())//2); y=max(0,(scaled.height()-size.height())//2)
                scaled=scaled.copy(x,y,min(size.width(),scaled.width()),min(size.height(),scaled.height()))
            else:
                scaled=pixmap.scaled(size,Qt.KeepAspectRatio,Qt.SmoothTransformation)
            self.external_label.setText(""); self.external_label.setPixmap(scaled)
        except Exception:
            LOGGER.exception("Ошибка обновления зеркала внешнего экрана")

    def save_calibration(self):
        # Slider callbacks update live values; normalize and persist to the active device profile.
        cal=normalize_calibration(CFG.get("calibration",{}))
        CFG["calibration"]=cal
        if self.device and self.connected:
            CFG.setdefault("calibration_profiles",{})[self.device]=copy.deepcopy(cal)
            self._calibration_device=self.device
        save_config(); log_event("INFO","Пресет кадрирования сохранён")
        if self.streaming:
            self.stop_stream(show_message=False,event_message="Перезапуск потока для применения кадрирования",preserve_external=True)
            QTimer.singleShot(500,self.toggle_stream)
        else:
            QMessageBox.information(self,"Калибровка","Пресет сохранён. Он применится при следующем запуске трансляции.")

    def reset_calibration(self):
        vals=copy.deepcopy(DEFAULT_CALIBRATION)
        CFG["calibration"]=vals.copy()
        for k,val in vals.items():
            adjustment=calibration_adjustment(k,val)
            self.cal_sliders[k].setValue(adjustment)
            if hasattr(self,"calibration_value_labels") and k in self.calibration_value_labels:
                self.calibration_value_labels[k].setText(self._format_calibration_adjustment(k,adjustment))
        if self.device and self.connected:
            CFG.setdefault("calibration_profiles",{})[self.device]=copy.deepcopy(vals)
            self._calibration_device=self.device
        save_config(); log_event("INFO","Кадрирование сброшено")
        if self.streaming:
            self.stop_stream(show_message=False,event_message="Перезапуск потока после сброса кадрирования",preserve_external=True)
            QTimer.singleShot(500,self.toggle_stream)
        self.update_osd()

    def refresh_video_encoders(self):
        """Query the selected headset for usable H.264 encoders via scrcpy."""
        if self.streaming or (self.scrcpy_proc is not None and self.scrcpy_proc.poll() is None):
            QMessageBox.information(self, "Остановите трансляцию", "Перед получением списка кодеров остановите текущую трансляцию.")
            return
        active_worker = getattr(self, "encoder_worker", None)
        if active_worker is not None and active_worker.isRunning():
            return
        serial=str(getattr(self, "device", "") or "").strip()
        if not serial or not getattr(self, "connected", False):
            QMessageBox.warning(self, "Нет подключения", "Сначала подключите и выберите Meta Quest 3, затем повторите поиск кодеров.")
            return
        scrcpy=resolve_binary("scrcpy")
        if not scrcpy:
            QMessageBox.warning(self, "scrcpy не найден", "Установите scrcpy на вкладке подключения и повторите поиск.")
            return
        self.encoder_refresh_btn.setEnabled(False)
        self.encoder_refresh_btn.setText("Поиск…")
        self.encoder_worker=VideoEncoderListWorker(scrcpy, serial, self)
        self.encoder_worker.completed.connect(self._on_video_encoders_loaded)
        self.encoder_worker.finished.connect(self._on_encoder_worker_finished)
        self.encoder_worker.start()

    def _on_encoder_worker_finished(self):
        worker=self.sender()
        if getattr(self, "encoder_worker", None) is worker:
            self.encoder_worker=None
        if worker is not None:
            worker.deleteLater()

    def _on_video_encoders_loaded(self, ok, encoders, detail):
        self.encoder_refresh_btn.setEnabled(True)
        self.encoder_refresh_btn.setText("Найти кодеры")
        if not ok:
            LOGGER.warning("Не удалось получить H.264-кодеры: %s", detail)
            QMessageBox.warning(self, "Кодеры не найдены", "Не удалось получить список H.264-кодеров. Проверьте версию scrcpy и подключение.\n\n"+detail)
            return
        current=str(self.video_encoder_combo.currentData() or "")
        self.video_encoder_combo.blockSignals(True)
        self.video_encoder_combo.clear()
        self.video_encoder_combo.addItem("Автоматически (выбор scrcpy)", "")
        for name in encoders:
            self.video_encoder_combo.addItem(name, name)
        index=self.video_encoder_combo.findData(current)
        self.video_encoder_combo.setCurrentIndex(index if index >= 0 else 0)
        self.video_encoder_combo.blockSignals(False)
        LOGGER.info("С устройства получен список H.264-кодеров (%d)", len(encoders))
        QMessageBox.information(self, "Список кодеров", "Найдено кодеров H.264: %d.\n\nПри ошибке MediaCodec выберите другой кодер и сохраните настройки." % len(encoders))

    def save_settings(self):
        old_stream_values=(CFG.get("eye"),CFG.get("resolution"),CFG.get("fps"),CFG.get("bitrate"),CFG.get("video_encoder", ""))
        CFG.update({"eye":self.eye_combo.currentText(),"resolution":self.res_combo.currentText(),
            "fps":self.fps_combo.currentText(),"bitrate":self.bitrate_spin.value(),
            "video_encoder":str(self.video_encoder_combo.currentData() or ""),
            "auto_bitrate":False,"auto_reconnect":self.auto_reconnect.isChecked(),
            "keep_awake":self.keep_awake.isChecked(),"language":"RU"})
        save_config(); self._apply_keep_awake(); log_event("INFO","Настройки сохранены"); self.refresh_state(); self.update_osd()
        new_stream_values=(CFG.get("eye"),CFG.get("resolution"),CFG.get("fps"),CFG.get("bitrate"),CFG.get("video_encoder", ""))
        will_restart=self.streaming and old_stream_values!=new_stream_values
        if will_restart:
            self.stop_stream(show_message=False,event_message="Перезапуск потока для применения новых настроек",preserve_external=True)
            QTimer.singleShot(500,self.toggle_stream)
        QMessageBox.information(self,"Настройки","Настройки сохранены."+(" Трансляция перезапускается для применения новых параметров." if will_restart else ""))

    def reset_settings(self):
        if QMessageBox.question(self,"Сброс настроек","Сбросить настройки к значениям по умолчанию?")!=QMessageBox.Yes: return
        was_streaming=self.streaming
        if was_streaming: self.stop_stream(show_message=False,event_message="Остановка для сброса настроек")
        CFG.clear(); CFG.update(copy.deepcopy(DEFAULTS)); save_config()
        self.eye_combo.setCurrentText(CFG["eye"]); self.eye_button.setText("◐ Глаз: "+CFG["eye"]); self.res_combo.setCurrentText(CFG["resolution"])
        self.fps_combo.setCurrentText(CFG["fps"]); self.bitrate_spin.setValue(CFG["bitrate"])
        self.video_encoder_combo.setCurrentIndex(max(0,self.video_encoder_combo.findData("")))
        self.auto_reconnect.setChecked(CFG["auto_reconnect"]); self.keep_awake.setChecked(CFG["keep_awake"])
        self.fit_combo.setCurrentText(CFG["external_fit"])
        self._apply_keep_awake()
        self.reset_calibration(); self.update_osd(); log_event("WARN","Настройки сброшены к значениям по умолчанию")
        if was_streaming: QTimer.singleShot(500,self.toggle_stream)
        QMessageBox.information(self,"Сброс","Настройки сброшены.")

    def select_headset(self, item):
        """Select only an ADB-authorized device; an offline row is never treated as connected."""
        try:
            if item is None: return
            serial=item.data(Qt.UserRole); state=item.data(Qt.UserRole+1); model=item.data(Qt.UserRole+2)
            if not serial: return
            if self.device and self.device != str(serial):
                self._resume_stream_after_reconnect=False  # A manually chosen device overrides pending recovery.
            if self.streaming and self.device != str(serial):
                self.stop_stream(show_message=False,event_message="Трансляция остановлена при смене устройства",preserve_external=True)
            if state!="device":
                QMessageBox.warning(self,"Устройство не готово", "Состояние ADB: "+str(state)+".\n\nЕсли указано unauthorized, разблокируйте шлем и подтвердите USB debugging.")
                self.device=str(serial); self.device_name=str(model or "Android device"); self.device_state=str(state); self.connected=False
                self._apply_keep_awake()
                self.refresh_state(); return
            self._activate_device_calibration(str(serial))
            self.device=str(serial); self.device_name=str(model or "Android device"); self.device_state="device"; self.connected=True
            if ":" not in self.device: CFG["last_ip"]=""
            save_config(); log_event("INFO","Выбрано авторизованное ADB-устройство")
            self.refresh_state(); self.start_metrics_scan(); self._apply_keep_awake()
        except Exception:
            LOGGER.exception("Ошибка выбора устройства из списка")
            log_event("ERROR","Не удалось выбрать устройство; подробности в logs/spectra.log")

    def refresh_state(self):
        if getattr(self,"scrcpy_proc",None) is not None and self.scrcpy_proc.poll() is not None and self.streaming:
            code=self.scrcpy_proc.returncode
            self.stop_stream(show_message=True,refresh=False,event_level="WARN",event_message=f"Процесс scrcpy завершился с кодом {code}; см. logs/scrcpy.log")
        if self.streaming:
            self.status.setText("● ТРАНСЛЯЦИЯ ИДЁТ"); self.status.setStyleSheet("color:#22c55e;font-weight:700;")
        elif self.connected:
            self.status.setText("● ПОДКЛЮЧЕНО"); self.status.setStyleSheet("color:#22d3ee;font-weight:700;")
        elif self.device and self.device_state:
            self.status.setText("● УСТРОЙСТВО НЕ ГОТОВО"); self.status.setStyleSheet("color:#eab308;font-weight:700;")
        else:
            self.status.setText("● НЕ ПОДКЛЮЧЕНО"); self.status.setStyleSheet("color:#9aa8bd;font-weight:700;")
        if hasattr(self,"disconnect_btn"):
            self.disconnect_btn.setEnabled(bool(self.device))
            self.disconnect_btn.setText("Отключить Wi-Fi / снять USB-выбор" if self.device else "Нет выбранного устройства")
        self.side_mode.setText("Режим: "+("Wi‑Fi" if ":" in self.device else "USB") if self.connected else "Режим: не подключено")
        self.side_ip.setText("Устройство: "+self.device if self.device else "Устройство: —")
        self.side_resolution.setText(f"Разрешение: {CFG['resolution']} · {CFG['fps']} FPS")
        if hasattr(self,"metric_labels"):
            self.metric_labels["bitrate"].setText(str(CFG.get("bitrate",16)))
        if self.connected:
            self.health_conn.setText("Подключено · "+("Wi-Fi" if ":" in self.device else "USB"))
            self.health_headset.setText(self.device_name or "Android device")
        else:
            self.health_conn.setText("Не подключено" if not self.device else "ADB: "+(self.device_state or "не найден"))
            self.health_headset.setText(self.device_name or "Не определён")
            # Never leave stale battery/latency values onscreen after disconnect.
            self.side_latency.setText("ADB round-trip: —")
            self.side_battery.setText("Заряд: —")
            self.health_battery.setText("Недоступно")
            if hasattr(self, "metric_labels"):
                self.metric_labels["latency"].setText("—")
                if not self.streaming:
                    self.metric_labels["fps"].setText("—")
        self.health_model.setText(self.adb_path or "ADB не найден")
        self.bottom_status.setText(f"Устройств: {len(self.devices)} · Режим: {('Wi‑Fi' if ':' in self.device else 'USB') if self.connected else '—'} · v{APP_VERSION} · {CFG['language']}")
        self._update_tools_status()
        self.update_osd()

    def on_log(self,level,line):
        self.console.append(line); self.refresh_logs()
    def toggle_console(self):
        self.console.setVisible(not self.console.isVisible())
        self.log_toggle.setText("⌃  Скрыть события" if self.console.isVisible() else "⌄  Последние события")
    def refresh_logs(self):
        if not hasattr(self,"log_view"): return
        path=LOG_DIR/"latest-log.txt"
        try:
            content=path.read_text(encoding="utf-8",errors="replace") if path.exists() else ""
            filt=self.log_filter.currentText() if hasattr(self,"log_filter") else "Всё"
            lines=content.splitlines()
            if filt=="Error": lines=[x for x in lines if "[ERROR]" in x]
            elif filt=="Warning": lines=[x for x in lines if "[WARN]" in x]
            elif filt=="Info": lines=[x for x in lines if "[INFO]" in x]
            lines=lines[-1000:]
            bar=self.log_view.verticalScrollBar()
            was_at_bottom=bar.value() >= bar.maximum()-2
            old_cursor=self.log_view.textCursor().position()
            self.log_view.setPlainText("\n".join(lines))
            if was_at_bottom:
                bar.setValue(bar.maximum())
            else:
                cursor=self.log_view.textCursor()
                cursor.setPosition(min(old_cursor,len(self.log_view.toPlainText())))
                self.log_view.setTextCursor(cursor)
        except Exception:
            LOGGER.exception("Не удалось прочитать журнал событий для интерфейса")
            self.log_view.setPlainText("Не удалось прочитать logs/latest-log.txt. Подробности см. в logs/spectra.log.")
    def _redact_diagnostics(self, content):
        """Mask IP addresses and known device serials before the user shares a report."""
        text=redact_ips(str(content))
        identifiers=set()
        if getattr(self,"device",""):
            identifiers.add(str(self.device))
        identifiers.update(str(d.get("serial","")) for d in getattr(self,"devices",[]) if d.get("serial"))
        identifiers.update(str(x) for x in getattr(self,"keep_awake_originals",{}).keys())
        identifiers.update(str(x) for x in CFG.get("calibration_profiles",{}).keys())
        saved=CFG.get("saved_headsets",[])
        if isinstance(saved,list):
            for item in saved:
                if isinstance(item,str): identifiers.add(item)
                elif isinstance(item,dict) and item.get("serial"): identifiers.add(str(item["serial"]))
        for identifier in sorted((x for x in identifiers if x and len(x)>=4),key=len,reverse=True):
            text=text.replace(identifier,"<DEVICE>")
        return text

    def export_diagnostics(self):
        suggested=APP_DIR/("SPECTRA-logs-"+datetime.now().strftime("%Y%m%d-%H%M%S")+".zip")
        filename,_=QFileDialog.getSaveFileName(self,"Экспорт логов",str(suggested),"ZIP архив (*.zip)")
        if not filename:
            return
        if not filename.lower().endswith(".zip"):
            filename += ".zip"
        try:
            included=[]
            with zipfile.ZipFile(filename,"w",compression=zipfile.ZIP_DEFLATED) as archive:
                for path in sorted(LOG_DIR.glob("*")):
                    is_log = path.suffix.lower() in {".log", ".txt"} or path.name.startswith("spectra.log.")
                    if path.is_file() and is_log:
                        # Redact LAN IP addresses from exported diagnostics.
                        content=path.read_text(encoding="utf-8",errors="replace")
                        content=self._redact_diagnostics(content)
                        archive.writestr("logs/"+path.name, content)
                        included.append(path.name)
                report=(f"SPECTRA diagnostics\nVersion: {APP_VERSION}\nTime: {stamp()}\nPython: {sys.version}\n"
                        f"Platform: {sys.platform}\nConnected: {self.connected}\n"
                        f"Device: {'configured' if self.device else 'none'}\nStreaming: {self.streaming}\n"
                        f"Log files: {', '.join(included) if included else 'none'}\n")
                archive.writestr("diagnostics.txt",report)
            log_event("INFO",f"Пакет диагностики экспортирован: {filename}")
            QMessageBox.information(self,"Экспорт завершён",f"Архив логов сохранён:\n{filename}\n\nФайлы логов: {len(included)}")
        except Exception as exc:
            LOGGER.exception("Не удалось экспортировать логи")
            log_event("ERROR",f"Не удалось экспортировать логи: {exc}")
            QMessageBox.critical(self,"Ошибка экспорта",f"Не удалось создать архив. См. logs/spectra.log.\n\n{exc}")
    def open_logs(self):
        self.open_path(LOG_DIR)
    def open_path(self,path):
        try:
            if sys.platform=="win32": os.startfile(str(path))
            else: subprocess.Popen(["xdg-open",str(path)])
        except Exception as e:
            LOGGER.exception("Не удалось открыть путь: %s", path)
            log_event("ERROR",f"Не удалось открыть путь {path}: {e}")
            QMessageBox.warning(self,"Не удалось открыть",str(e))
    def copy_report(self):
        safe_settings = copy.deepcopy(CFG)
        safe_settings.pop("keep_awake_originals", None)  # May contain physical device serials.
        safe_settings.pop("calibration_profiles", None)  # Device serials are profile keys.
        safe_settings.pop("saved_headsets", None)
        report=f"SPECTRA {APP_VERSION}\nВремя: {stamp()}\nПодключено: {self.connected}\nУстройство: {'выбрано' if self.device else '—'}\nТрансляция: {self.streaming}\nНастройки: {json.dumps(safe_settings,ensure_ascii=False)}\n\nПоследние логи:\n"
        p=LOG_DIR/"latest-log.txt"
        if p.exists(): report += "\n".join(p.read_text(encoding="utf-8",errors="replace").splitlines()[-100:])
        report=self._redact_diagnostics(report)
        QApplication.clipboard().setText(report); QMessageBox.information(self,"Отчёт","Отчёт скопирован в буфер обмена. IPv4-адреса скрыты; серийный номер выбранного устройства не добавляется.")
    def closeEvent(self,event):
        # Qt cannot safely destroy a QThread while it is still running. Ask blocking
        # worker operations to stop, then retry closing on the event loop while they unwind.
        worker_names=("scan_worker","metrics_worker","stream_prep_worker","wifi_worker","tools_worker","encoder_worker")
        active=[]
        for name in worker_names:
            worker=getattr(self,name,None)
            if worker is not None and worker.isRunning():
                active.append(worker)
                try: worker.requestInterruption()
                except Exception: pass
        if active:
            self._closing_requested=True
            self.setEnabled(False)
            if not self._close_retry_scheduled:
                self._close_retry_scheduled=True
                QTimer.singleShot(600,self._retry_close)
            event.ignore()
            return
        try:
            for timer_name in ("timer","scan_timer","metrics_timer","embed_timer","external_timer"):
                timer=getattr(self,timer_name,None)
                if timer is not None: timer.stop()
            if self.streaming or self.scrcpy_proc is not None:
                self.stop_stream(show_message=False,refresh=False,event_message="SPECTRA остановлена; поток завершён")
            self._restore_keep_awake()
            CFG["keep_awake"]=False
            save_config(); log_event("INFO","SPECTRA завершает работу")
        except Exception:
            LOGGER.exception("Ошибка при завершении приложения")
        event.accept()

    def _retry_close(self):
        self._close_retry_scheduled=False
        self.close()


def main():
    LOGGER.info("Запуск SPECTRA; Python=%s; executable=%s; platform=%s", sys.version.replace("\n", " "), sys.executable, sys.platform)
    try:
        app=QApplication(sys.argv); app.setStyle("Fusion"); app.setStyleSheet(STYLE)
        window=App(); window.show()
        sys.exit(app.exec())
    except SystemExit:
        raise
    except Exception:
        LOGGER.exception("Критическая ошибка при запуске/работе интерфейса")
        raise
if __name__=="__main__": main()
