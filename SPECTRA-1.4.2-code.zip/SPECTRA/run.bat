@echo off
setlocal EnableExtensions
cd /d "%~dp0"
chcp 65001 >nul
set "PYTHONUTF8=1"
title SPECTRA - Launcher

if not exist "logs" mkdir "logs"
if not exist "config" mkdir "config"
set "LOG=%CD%\logs\launcher.log"
>>"%LOG%" echo ==================================================
>>"%LOG%" echo SPECTRA launcher started %DATE% %TIME%

echo ==========================================
echo SPECTRA - STARTUP CHECK
echo ==========================================
set "PYTHON_EXE="
if exist ".venv\Scripts\python.exe" set "PYTHON_EXE=%CD%\.venv\Scripts\python.exe"
if defined PYTHON_EXE goto CHECK_PYTHON

where py >nul 2>&1
if errorlevel 1 goto TRY_PYTHON
echo Creating virtual environment...
py -3 -m venv .venv >>"%LOG%" 2>&1
if errorlevel 1 goto PY_LAUNCHER_FAILED
set "PYTHON_EXE=%CD%\.venv\Scripts\python.exe"
goto CHECK_PYTHON

:PY_LAUNCHER_FAILED
>>"%LOG%" echo py -3 failed. Trying python command.
if exist ".venv" rmdir /s /q ".venv" >>"%LOG%" 2>&1

:TRY_PYTHON
where python >nul 2>&1
if errorlevel 1 goto NO_PYTHON
echo Creating virtual environment with python...
python -m venv .venv >>"%LOG%" 2>&1
if errorlevel 1 goto VENV_FAILED
set "PYTHON_EXE=%CD%\.venv\Scripts\python.exe"
goto CHECK_PYTHON

:VENV_FAILED
echo ERROR: Could not create Python virtual environment.
>>"%LOG%" echo ERROR: Could not create virtual environment.
goto ERROR_EXIT

:NO_PYTHON
echo ERROR: Python was not found.
>>"%LOG%" echo ERROR: Python was not found.
echo Install Python 3.11 or newer from:
echo https://www.python.org/downloads/windows/
goto ERROR_EXIT

:CHECK_PYTHON
if not exist "%PYTHON_EXE%" goto NO_PYTHON
"%PYTHON_EXE%" -c "import sys; raise SystemExit(0 if sys.version_info >= (3,11) else 1)" >nul 2>&1
if errorlevel 1 goto OLD_PYTHON
"%PYTHON_EXE%" -m pip --version >nul 2>&1
if errorlevel 1 goto PIP_MISSING
goto CHECK_PYSIDE

:PIP_MISSING
echo Initializing pip...
"%PYTHON_EXE%" -m ensurepip --upgrade >>"%LOG%" 2>&1
if errorlevel 1 goto PIP_FAILED

:CHECK_PYSIDE
"%PYTHON_EXE%" -c "from PySide6.QtCore import Qt; print(Qt)" >nul 2>&1
if not errorlevel 1 goto START_APP
echo Installing required Python packages. This may take a few minutes...
"%PYTHON_EXE%" -m pip install --upgrade pip >>"%LOG%" 2>&1
if errorlevel 1 goto INSTALL_FAILED
"%PYTHON_EXE%" -m pip install -r requirements.txt >>"%LOG%" 2>&1
if errorlevel 1 goto INSTALL_FAILED

:START_APP
echo Starting SPECTRA...
echo Logs: %CD%\logs\spectra.log
>>"%LOG%" echo Dependencies ready. Starting app.
"%PYTHON_EXE%" app.py
set "APP_EXIT=%ERRORLEVEL%"
>>"%LOG%" echo App exited with code %APP_EXIT%
if "%APP_EXIT%"=="0" goto NORMAL_EXIT
echo SPECTRA exited with an error.
echo Check logs\spectra.log and logs\launcher.log
goto ERROR_EXIT

:OLD_PYTHON
echo ERROR: SPECTRA requires Python 3.11 or newer.
>>"%LOG%" echo ERROR: Python version is too old.
goto ERROR_EXIT

:INSTALL_FAILED
echo ERROR: Dependency installation failed.
echo Check logs\launcher.log for installation details.
>>"%LOG%" echo ERROR: Dependency installation failed.
goto ERROR_EXIT

:PIP_FAILED
echo ERROR: Could not initialize pip.
>>"%LOG%" echo ERROR: Could not initialize pip.
goto ERROR_EXIT

:NORMAL_EXIT
echo SPECTRA closed.
endlocal
exit /b 0

:ERROR_EXIT
echo.
echo See logs\launcher.log for details.
pause
endlocal
exit /b 1
